package vos;

import java.util.ArrayList;

import org.codehaus.jackson.annotate.JsonProperty;

public class Producto
{
	//Constantes
	public static String ENTRADA = "Entrada";
	public static String PLATOFUERTE = "Plato Fuerte";
	public static String ACOMPANAMIENTOS = "Acompanamientos";
	public static String BEBIDAS = "Bebidas";
	public static String POSTRES = "Postres";
	
	
	//Atributos
	private int idProducto;
	private String nombre;
	private double precioProducto;
	private double costoProducto;
	private String descripEsp;
	private String descripIng;
	private int tiempoPreparacion;
	private ArrayList<Integer> ingredientes= new ArrayList<Integer>();
	private boolean estaPersonalizado;
	private String tipoProducto;
	private int disponibilidad;
	private int unidadesVendidas;
	//Iteracion 3
	private ArrayList<Integer> idProductos = new ArrayList<Integer>();

	public Producto(@JsonProperty(value="idProducto")int idProducto, @JsonProperty(value="nombre")String nombre
			, @JsonProperty(value="precioProducto")double precioProducto, @JsonProperty(value="costoProducto")double costoProducto
			, @JsonProperty(value="descripEsp")String descripEsp,@JsonProperty(value="decripIng")String descripIng
			, @JsonProperty(value="tiempoPreparacion")int tiempoPreparacion, @JsonProperty(value="estaPersonalizado")boolean estaPersonalizado,
			@JsonProperty(value="tipoProducto")String tipoProducto, @JsonProperty(value="disponibilidad")int pDisponibilidad
			, @JsonProperty(value="unidadesVendidas")int pUnidadesVendidas)
	{
		super();
		this.idProducto = idProducto;
		this.nombre = nombre;
		this.precioProducto = precioProducto;
		this.costoProducto = costoProducto;
		this.descripEsp = descripEsp;
		this.descripIng = descripIng;
		this.tiempoPreparacion = tiempoPreparacion;
		this.estaPersonalizado = estaPersonalizado;
		this.tipoProducto = tipoProducto;
		this.disponibilidad=pDisponibilidad;
		this.unidadesVendidas=pUnidadesVendidas;
	}

	public int getIdProducto() {
		return idProducto;
	}

	public void setIdProducto(int idProducto) {
		this.idProducto = idProducto;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public double getPrecioProducto() {
		return precioProducto;
	}

	public void setPrecioProducto(double precioProducto) {
		this.precioProducto = precioProducto;
	}

	public double getCostoProducto() {
		return costoProducto;
	}

	public void setCostoProducto(double costoProducto) {
		this.costoProducto = costoProducto;
	}

	public String getDescripEsp() {
		return descripEsp;
	}

	public void setDescripEsp(String descripEsp) {
		this.descripEsp = descripEsp;
	}

	public String getDescripIng() {
		return descripIng;
	}

	public void setDescripIng(String descripIng) {
		this.descripIng = descripIng;
	}

	public int getTiempoPreparacion() {
		return tiempoPreparacion;
	}

	public void setTiempoPreparacion(int tiempoPreparacion) {
		this.tiempoPreparacion = tiempoPreparacion;
	}

	public ArrayList<Integer> getIngredientes() {
		return ingredientes;
	}

	public void setIngredientes(ArrayList<Integer> ingredientes) {
		this.ingredientes = ingredientes;
	}

	public boolean isEstaPersonalizado() {
		return estaPersonalizado;
	}

	public void setEstaPersonalizado(boolean estaPersonalizado) {
		this.estaPersonalizado = estaPersonalizado;
	}

	public String getTipoProducto() {
		return tipoProducto;
	}

	public void setTipoProducto(String tipoProducto) {
		this.tipoProducto = tipoProducto;
	}

	public int getDisponibilidad() {
		return disponibilidad;
	}

	public void setDisponibilidad(int disponibilidad) {
		this.disponibilidad = disponibilidad;
	}

	public int getUnidadesVendidas() {
		return unidadesVendidas;
	}

	public void setUnidadesVendidas(int unidadesVendidas) {
		this.unidadesVendidas = unidadesVendidas;
	}
	//Iteracion 3
	public int aumentarDisponibilidad()
	{
		return disponibilidad++;
	}

	public ArrayList<Integer> getIdProductos() {
		return idProductos;
	}

	public void setIdProductos(ArrayList<Integer> idProductos) {
		this.idProductos = idProductos;
	}

	
	
	

}
