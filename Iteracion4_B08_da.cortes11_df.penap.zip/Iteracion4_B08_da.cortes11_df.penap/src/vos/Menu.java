package vos;

import java.util.ArrayList;

import org.codehaus.jackson.annotate.JsonProperty;

public class Menu {
	
	private String nombre;
	private int idMenu;
	private double precio;
	private double costo;
	private boolean estaPersonalisado;
	private int idRestaurante;
	private ArrayList<Integer> idProductos= new ArrayList<Integer>();
	
	public Menu(@JsonProperty(value="nombre")String nombre, @JsonProperty(value="idMenu")int idMenu, 
			@JsonProperty(value="precio")double precio, @JsonProperty(value="costo")double costo,
			@JsonProperty(value="estaPersonalizado")boolean estaPersonalisado
			,@JsonProperty(value="idRestaurante") int idRestaurante)
	{
		super();
		this.nombre = nombre;
		this.idMenu = idMenu;
		this.precio = precio;
		this.costo = costo;
		this.estaPersonalisado = estaPersonalisado;
		this.idRestaurante = idRestaurante;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getIdMenu() {
		return idMenu;
	}

	public void setIdMenu(int idMenu) {
		this.idMenu = idMenu;
	}

	public double getPrecio() {
		return precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}

	public double getCosto() {
		return costo;
	}

	public void setCosto(double costo) {
		this.costo = costo;
	}

	public boolean isEstaPersonalisado() {
		return estaPersonalisado;
	}

	public void setEstaPersonalisado(boolean estaPersonalisado) {
		this.estaPersonalisado = estaPersonalisado;
	}

	public int getIdRestaurante() {
		return idRestaurante;
	}

	public void setIdRestaurante(int idRestaurante) {
		this.idRestaurante = idRestaurante;
	}

	public ArrayList<Integer> getIdProductos() {
		return idProductos;
	}

	public void setIdProductos(ArrayList<Integer> idProductos) {
		this.idProductos = idProductos;
	}
	
	
	
	
	
	
	
	
}

