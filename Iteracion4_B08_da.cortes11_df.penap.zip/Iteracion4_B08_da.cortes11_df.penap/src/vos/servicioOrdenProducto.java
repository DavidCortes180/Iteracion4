package vos;

import org.codehaus.jackson.annotate.JsonProperty;

public class servicioOrdenProducto {
	private Orden orden;
	private Producto producto;
	public servicioOrdenProducto(@JsonProperty(value="orden")Orden orden, @JsonProperty(value="producto")Producto producto) {
		// TODO Auto-generated constructor stub
		this.setOrden(orden);
		this.setProducto(producto);
	}
	public Orden getOrden() {
		return orden;
	}
	public void setOrden(Orden orden) {
		this.orden = orden;
	}
	public Producto getProducto() {
		return producto;
	}
	public void setProducto(Producto producto) {
		this.producto = producto;
	}
}
