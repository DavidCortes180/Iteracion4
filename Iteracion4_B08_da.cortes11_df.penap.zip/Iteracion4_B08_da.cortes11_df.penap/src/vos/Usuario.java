package vos;

import org.codehaus.jackson.annotate.JsonProperty;

public class Usuario 
{
	public static String ADMINISTRADOR ="Administrador";
	public static String RESTAURANTE ="Restaurante";
	public static String CLIENTE = "Cliente";
	
	private int identificacion;
	private String nombre;
	private String correo;
	private String rol;
	private RotonAndesVirtual plataforma=null;
	
	public Usuario(@JsonProperty(value="identificacion")int identificacion, @JsonProperty(value="nombre")String nombre
			, @JsonProperty(value="correo")String correo, @JsonProperty(value="rol")String rol) 
	{
		super();
		this.identificacion = identificacion;
		this.nombre = nombre;
		this.correo = correo;
		this.rol = rol;
	}
	
	
	public int getIdentificacion() {
		return identificacion;
	}
	
	public void setIdentificacion(int identificacion) {
		this.identificacion = identificacion;
	}
	
	public String getNombre() {
		return nombre;
	}
	
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	public String getRol() {
		return rol;
	}
	
	public void setRol(String rol) {
		this.rol = rol;
	}
	
	public String getCorreo() {
		return correo;
	}
	
	public void setCorreo(String correo) {
		this.correo = correo;
	}
	
	public RotonAndesVirtual getPlataforma() {
		return plataforma;
	}
	
	public void setPlataforma(RotonAndesVirtual plataforma) {
		this.plataforma = plataforma;
	}


}
