package vos;

import org.codehaus.jackson.annotate.JsonProperty;

public class EquivalenciaProductos {
	private Producto producto1;
	private Producto producto2;
	public EquivalenciaProductos(@JsonProperty(value="producto1")Producto producto1,
			@JsonProperty(value="producto2")Producto producto2) {
		// TODO Auto-generated constructor stub
		this.producto1 = producto1;
		this.producto2 = producto2;
	}
	public Producto getproducto1()
	{
		return producto1;
	}
	public Producto getproducto2()
	{
		return producto2;
	}
}
