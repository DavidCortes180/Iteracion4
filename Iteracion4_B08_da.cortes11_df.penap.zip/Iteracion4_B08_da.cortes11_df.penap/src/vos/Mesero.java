package vos;

import java.util.ArrayList;

public class Mesero {
	
	private String nombre;
	private int idMesero;
	private Restaurante restaurante;
	private ArrayList<Orden> ordenes;
	public Mesero(String nombre, int idMesero, Restaurante restaurante,
			ArrayList<Orden> ordenes) {
		super();
		this.setNombre(nombre);
		this.setIdMesero(idMesero);
		this.setRestaurante(restaurante);
		this.setOrdenes(ordenes);
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public int getIdMesero() {
		return idMesero;
	}
	public void setIdMesero(int idMesero) {
		this.idMesero = idMesero;
	}
	public Restaurante getRestaurante() {
		return restaurante;
	}
	public void setRestaurante(Restaurante restaurante) {
		this.restaurante = restaurante;
	}
	public ArrayList<Orden> getOrdenes() {
		return ordenes;
	}
	public void setOrdenes(ArrayList<Orden> ordenes) {
		this.ordenes = ordenes;
	}
	
	
}
