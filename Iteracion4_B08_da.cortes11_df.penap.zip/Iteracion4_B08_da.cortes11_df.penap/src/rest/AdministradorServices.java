package rest;

import java.util.ArrayList;

import javax.servlet.ServletContext;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;

import tm.Master;
import vos.Cliente;
import vos.Orden;
import vos.Producto;
import vos.Restaurante;
import vos.Usuario;
import vos.Zona;

@javax.ws.rs.Path("administradorServices")
public class AdministradorServices {
	@Context
	private ServletContext context;

	private String getPath() 
	{
		return context.getRealPath("WEB-INF/ConnectionData");
	}
	
	private String doErrorMessage(Exception e){
		return "{ \"ERROR\": \""+ e.getMessage() + "\"}" ;
	}
	
	//RF2
	@POST
	@Path("/administrador/agregarCliente")
	@Produces({ MediaType.APPLICATION_JSON })
	@Consumes(MediaType.APPLICATION_JSON)
	public Response registrarCliente(Cliente pCliente)
	{
		Master mas = Master.darInstancia(getPath());
		try 
		{
			mas.registrarCliente(pCliente);
		} catch (Exception e) {
			return Response.status(500).entity(doErrorMessage(e)).build();
		}
		return Response.status(200).entity(pCliente).build();
	}
	
	//RF3
	@POST
	@Path("/administrador/agregarRestaurante")
	@Produces({ MediaType.APPLICATION_JSON })
	@Consumes(MediaType.APPLICATION_JSON)
	public Response registrarRestaurante(Restaurante pRestaurante)
	{
		Master mas = Master.darInstancia(getPath());
		try 
		{
			mas.registrarRestaurante(pRestaurante);
		} catch (Exception e) {
			return Response.status(500).entity(doErrorMessage(e)).build();
		}
		return Response.status(200).entity(pRestaurante).build();
	}
	

	
	//RF7
	@POST
	@Path("/administrador/agregarSitio")
	@Produces({ MediaType.APPLICATION_JSON })
	@Consumes(MediaType.APPLICATION_JSON)
	public Response registrarZona(Zona pZona)
	{
		Master mas = Master.darInstancia(getPath());
		try 
		{
			mas.registrarZona(pZona);
		} catch (Exception e) {
			return Response.status(500).entity(doErrorMessage(e)).build();
		}
		return Response.status(200).entity(pZona).build();
	}
	//iteracion 3
		//RFC7 Administrador 
	@GET
	@Path("/administrador/consultarproductosconsumidos/{id: \\d+}")
	@Produces({ MediaType.APPLICATION_JSON })
	
	public Response consultarProductosConsumidos(@PathParam( "id" )int idCliente )
	{
		Master mas = Master.darInstancia(getPath());
		ResponseBuilder respuesta = Response.status(200);
		try 
		{
			ArrayList<Producto> productos = mas.consultarConsumoClienteAdministrador(idCliente);
			respuesta.entity(productos);
			
			
		} catch (Exception e) {
			return Response.status(500).entity(doErrorMessage(e)).build();
		}
		return respuesta.build();
	}
		//RFC8 Administrador 	
	@GET
	@Path("/administrador/consultarpedidos")
	@Produces({ MediaType.APPLICATION_JSON })
	public Response consultarPedidoAdministrador()
	{
		Master mas = Master.darInstancia(getPath());
		ResponseBuilder respuesta = Response.status(200);
		try 
		{
			ArrayList<Orden> ordenes = mas.consultarPedidosAdministrador();
			respuesta.entity(ordenes);
			
			
		} catch (Exception e) {
			return Response.status(500).entity(doErrorMessage(e)).build();
		}
		return respuesta.build();
	}
	//iteracion 4
	//RFC9
	@GET
	@Path("/administrador/consultarConsumoA")
	@Produces({ MediaType.APPLICATION_JSON })
	public Response consultarConsumoA()
	{
		Master mas = Master.darInstancia(getPath());
		ResponseBuilder respuesta = Response.status(200);
		try 
		{
			ArrayList<Usuario> usuarios = mas.consultarConsumoVersionAGerente();
			respuesta.entity(usuarios);
			
			
		} catch (Exception e) {
			return Response.status(500).entity(doErrorMessage(e)).build();
		}
		return respuesta.build();
	}
	//RFC10
	@GET
	@Path("/administrador/consultarConsumoB")
	@Produces({ MediaType.APPLICATION_JSON })
	public Response consultarConsumoB()
	{
		Master mas = Master.darInstancia(getPath());
		ResponseBuilder respuesta = Response.status(200);
		try 
		{
			ArrayList<Usuario> usuarios = mas.consultarConsumoVersionBGerente();
			respuesta.entity(usuarios);
			
			
		} catch (Exception e) {
			return Response.status(500).entity(doErrorMessage(e)).build();
		}
		return respuesta.build();
	}
	//RFC11
	@GET
	@Path("/administrador/consultarFuncionamiento")
	@Produces({ MediaType.APPLICATION_JSON })
	public Response consultarFuncionamiento()
	{
		Master mas = Master.darInstancia(getPath());
		ResponseBuilder respuesta = Response.status(200);
		try 
		{
			ArrayList<Restaurante> restaurantes = mas.consultarFuncionamiento();
			respuesta.entity(restaurantes);
			
			
		} catch (Exception e) {
			return Response.status(500).entity(doErrorMessage(e)).build();
		}
		return respuesta.build();
	}
	//RFC12
	@GET
	@Path("/administrador/consultarBuenosUsuarios")
	@Produces({ MediaType.APPLICATION_JSON })
	public Response consultarBuenosUsuarios()
	{
		Master mas = Master.darInstancia(getPath());
		ResponseBuilder respuesta = Response.status(200);
		try 
		{
			ArrayList<Cliente> usuarios = mas.consultarBuenosClientes();
			respuesta.entity(usuarios);
			
			
		} catch (Exception e) {
			return Response.status(500).entity(doErrorMessage(e)).build();
		}
		return respuesta.build();
	}
}
