package rest;

import java.util.ArrayList;

import javax.servlet.ServletContext;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.annotate.JsonProperty;

import tm.Master;
import vos.Cliente;
import vos.EquivalenciaIngredientes;
import vos.EquivalenciaProductos;
import vos.Ingrediente;
import vos.Menu;
import vos.Orden;
import vos.Producto;
import vos.Restaurante;
import vos.Usuario;
import vos.servicioOrdenProducto;

@javax.ws.rs.Path("restauranteServices")
public class RestauranteServices {
	@Context
	private ServletContext context;

	private String getPath() 
	{
		return context.getRealPath("WEB-INF/ConnectionData");
	}
	
	private String doErrorMessage(Exception e){
		return "{ \"ERROR\": \""+ e.getMessage() + "\"}" ;
	}
	//RF4
	@POST
	@Path("/restaurante/agregarproducto")
	@Produces({ MediaType.APPLICATION_JSON })
	@Consumes(MediaType.APPLICATION_JSON)
	public Response registrarProducto(Producto producto)
	{
		Master mas = Master.darInstancia(getPath());
		try 
		{
			mas.registrarProducto(producto);
		} catch (Exception e) {
			return Response.status(500).entity(doErrorMessage(e)).build();
		}
		return Response.status(200).entity(producto).build();
	}
	//RF5
		@POST
		@Path("/restaurante/agregaringrediente")
		@Produces({ MediaType.APPLICATION_JSON })
		@Consumes(MediaType.APPLICATION_JSON)
		public Response registrarIngrediente(Ingrediente ingrediente)
		{
			Master mas = Master.darInstancia(getPath());
			try 
			{
				mas.registrarIngrediente(ingrediente);
			} catch (Exception e) {
				return Response.status(500).entity(doErrorMessage(e)).build();
			}
			return Response.status(200).entity(ingrediente).build();
		}
	//RF6
		@POST
		@Path("/restaurante/agregarmenu")
		@Produces({ MediaType.APPLICATION_JSON })
		@Consumes(MediaType.APPLICATION_JSON)
		public Response registrarMenu(Menu menu)
		{
			Master mas = Master.darInstancia(getPath());
			try 
			{
				mas.registrarMenu(menu);
			} catch (Exception e) {
				return Response.status(500).entity(doErrorMessage(e)).build();
			}
			return Response.status(200).entity(menu).build();
		}
	//RF10
		@POST
		@Path("/restaurante/agregarservicioproducto")
		@Produces({ MediaType.APPLICATION_JSON })
		@Consumes(MediaType.APPLICATION_JSON)
		public Response registrarServicioProducto(Producto producto)
		{
			Master mas = Master.darInstancia(getPath());
			try 
			{
				mas.registrarServicioProducto(producto);
			} catch (Exception e) {
				return Response.status(500).entity(doErrorMessage(e)).build();
			}
			return Response.status(200).entity(producto	).build();
		}
		//iteracion 3
		
			//RF11
		@POST
		@Path("/restaurante/agregarequivalenciaingrediente")
		@Produces({ MediaType.APPLICATION_JSON })
		@Consumes(MediaType.APPLICATION_JSON)
		public Response registrarEquivalenciaIngrediente(EquivalenciaIngredientes cambio)
		{
			Master mas = Master.darInstancia(getPath());
			try 
			{
				mas.registrarEquivalenciaIngrediente(cambio.getIngrediente1(),cambio.getIngrediente2());
				cambio.getIngrediente1().getIdIngredientes().add(cambio.getIngrediente2().getIdIngrediente());
			} catch (Exception e) {
				return Response.status(500).entity(doErrorMessage(e)).build();
			}
			return Response.status(200).entity(cambio.getIngrediente1()).build();
		}
			//RF12
		@POST
		@Path("/restaurante/agregarequivalenciaproducto")
		@Produces({ MediaType.APPLICATION_JSON })
		@Consumes(MediaType.APPLICATION_JSON)
		public Response registrarEquivalenciaProductos(EquivalenciaProductos cambio)
		{
			Master mas = Master.darInstancia(getPath());
			try 
			{
				mas.registrarEquivalenciaProductos(cambio.getproducto1(),cambio.getproducto2());
				cambio.getproducto1().getIdProductos().add(cambio.getproducto2().getIdProducto());
			} catch (Exception e) {
				return Response.status(500).entity(doErrorMessage(e)).build();
			}
			return Response.status(200).entity(cambio.getproducto1()).build();
		}
			//RF13
		@POST
		@Path("/restaurante/surtirrestaurante")
		@Produces({ MediaType.APPLICATION_JSON })
		@Consumes(MediaType.APPLICATION_JSON)
		public Response surtirRestaurante(Restaurante restaurante)
		{
			Master mas = Master.darInstancia(getPath());
			try 
			{
				mas.surtirRestaurante(restaurante);
			} catch (Exception e) {
				return Response.status(500).entity(doErrorMessage(e)).build();
			}
			return Response.status(200).entity(restaurante).build();
		}
			//RF14
		@POST
		@Path("/restaurante/registrarpedidoproductoequivalencias")
		@Produces({ MediaType.APPLICATION_JSON })
		@Consumes(MediaType.APPLICATION_JSON)
		public Response registrarPedidoProductoEquivalencias(Orden pOrden)
		{
			Master mas = Master.darInstancia(getPath());
			try 
			{
				mas.registrarPedidoProductoEquivalencias(pOrden);
			} catch (Exception e) {
				return Response.status(500).entity(doErrorMessage(e)).build();
			}
			return Response.status(200).entity(pOrden).build();
		}
			//RF15
		@POST
		@Path("/restaurante/registrarpedidoproductomesa")
		@Produces({ MediaType.APPLICATION_JSON })
		@Consumes(MediaType.APPLICATION_JSON)
		public Response registrarPedidoProductoMesa(Orden orden)
		{
			Master mas = Master.darInstancia(getPath());
			try 
			{
				mas.registrarPedidoProductoMesa(orden);
			} catch (Exception e) {
				return Response.status(500).entity(doErrorMessage(e)).build();
			}
			return Response.status(200).entity(orden).build();
		}
			//RF16
		@POST
		@Path("/restaurante/registrarserviciomesa")
		@Produces({ MediaType.APPLICATION_JSON })
		@Consumes(MediaType.APPLICATION_JSON)
		public Response registrarServicioMesa(servicioOrdenProducto servicio) 
		{
			Master mas = Master.darInstancia(getPath());
			try 
			{
				mas.registrarServicioMesa(servicio.getOrden(),servicio.getProducto());
			} catch (Exception e) {
				return Response.status(500).entity(doErrorMessage(e)).build();
			}
			return Response.status(200).entity(servicio.getOrden()).build();
		}
			//RF17
		@DELETE
		@Path("/restaurante/cancelarpedido")
		@Produces({ MediaType.APPLICATION_JSON })
		@Consumes(MediaType.APPLICATION_JSON)
		public Response cancelarPedido(Orden pOrden)
		{
			Master mas = Master.darInstancia(getPath());
			try 
			{
				mas.cancelarPedido(pOrden);
			} catch (Exception e) {
				return Response.status(500).entity(doErrorMessage(e)).build();
			}
			return Response.status(200).entity(pOrden).build();
		}
		//RFC8
		@GET
		@Path("/restaurante/consultarpedido/{id: \\d+}")
		@Produces({ MediaType.APPLICATION_JSON })
		public Response consultarPedido(@PathParam( "id" )int idCliente)
		{
			Master mas = Master.darInstancia(getPath());
			ResponseBuilder respuesta = Response.status(200);
			try 
			{
				ArrayList<Orden> ordenes = mas.consultarPedido(idCliente);
				for (int i = 0; i < ordenes.size(); i++) {
					Orden productoActual = ordenes.get(i);
					respuesta.entity(productoActual);
				}
				
			} catch (Exception e) {
				return Response.status(500).entity(doErrorMessage(e)).build();
			}
			return respuesta.build();
		}
		//Iteracion 4
		//RFC9
		@GET
		@Path("/restaurante/consultarConsumoA/{id: \\d+}")
		@Produces({ MediaType.APPLICATION_JSON })
		public Response consultarConsumoA(@PathParam( "id" )int idRestaurante)
		{
			Master mas = Master.darInstancia(getPath());
			ResponseBuilder respuesta = Response.status(200);
			try 
			{
				ArrayList<Usuario> usuarios = mas.consultarConsumoVersionAUsuario(idRestaurante);
				respuesta.entity(usuarios);
				
			} catch (Exception e) {
				return Response.status(500).entity(doErrorMessage(e)).build();
			}
			return respuesta.build();
		}
		//RFC10
		@GET
		@Path("/restaurante/consultarConsumoB/{id: \\d+}")
		@Produces({ MediaType.APPLICATION_JSON })
		public Response consultarConsumoB(@PathParam( "id" )int idRestaurante)
		{
			Master mas = Master.darInstancia(getPath());
			ResponseBuilder respuesta = Response.status(200);
			try 
			{
				ArrayList<Usuario> usuarios = mas.consultarConsumoVersionBUsuario(idRestaurante);
				respuesta.entity(usuarios);
				
			} catch (Exception e) {
				return Response.status(500).entity(doErrorMessage(e)).build();
			}
			return respuesta.build();
		}
}
