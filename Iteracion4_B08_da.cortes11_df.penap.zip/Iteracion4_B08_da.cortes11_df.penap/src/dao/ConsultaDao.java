package dao;

import java.io.File;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Properties;
import java.util.Random;
import java.util.function.Function;
import java.util.stream.IntStream;

import org.codehaus.jackson.map.ser.ArraySerializers.BooleanArraySerializer;

import vos.Cliente;
import vos.Ingrediente;
import vos.Orden;
import vos.Producto;
import vos.Restaurante;
import vos.Usuario;
import vos.Zona;


public class ConsultaDao 
{

	private Connection conexion;
	
	private String user;
	
	private String password;
	
	private String url;
	
	private String driver;
	
//	Format formatoFecha= SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
	
	public ConsultaDao(String connectionData) 
	{
		// TODO Auto-generated constructor stub
		inicializarConnectionData(connectionData);
	}
	
	public Connection getConexion() {
		return conexion;
	}
	
	private void inicializarConnectionData(String conectionData)
	{
		try 
		{
			File archivo= new File(conectionData);
			Properties propertie= new Properties();
			FileInputStream input= new FileInputStream(archivo);
			propertie.load(input);
			input.close();
			this.url= propertie.getProperty("url");
			this.user = propertie.getProperty("usuario");
			this.password = propertie.getProperty("clave");
			this.driver = propertie.getProperty("driver");
			Class.forName(driver);
		} 
		catch (Exception e) 
		{
			// TODO: handle exception
			e.printStackTrace();
		}
	}
	
	private void establecerConexion() throws SQLException
	{
		System.out.println("Connecting to: " + url + " With user: " + user);
		conexion = DriverManager.getConnection(url, user, password);
	}
	
	public void cerrarConnection(Connection connection) throws SQLException
	{
		try 
		{
			connection.close();
			connection= null;
			
		} catch (SQLException e) 
		{
			// TODO: handle exception
			System.err.println("SQLException in closing Connection:");
			e.printStackTrace();
			throw e;
		}
	}

	
	//Requerimientos
	
	
	//funcionales
	
	//RF1- Registrar Usuario
	public void registrarUsuario(Usuario pUsuario)throws Exception
	{
		PreparedStatement prepStmt= null;
		
		try
		{
			System.out.println(pUsuario);
			establecerConexion();
			String sql = "INSERT INTO USUARIO(IDUSUARIO, NOMBRE, CORREO, ROL)"+
					"VALUES("+pUsuario.getIdentificacion()+",'"+pUsuario.getNombre()+"','"+
					pUsuario.getCorreo()+"',"+pUsuario.getRol()+")";
			System.out.println(sql);
			prepStmt= conexion.prepareStatement(sql);
			prepStmt.execute();
		} 
		catch (Exception e)
		{
			// TODO: handle exception
			System.err.println("SQLException in executing:");
			e.printStackTrace();
		}
		finally
		{
			if (prepStmt!=null)
			{
				try 
				{
					prepStmt.close();
				} 
				catch (SQLException e2) 
				{
					// TODO: handle exception
					System.err.println("SQLException in closing Stmt:");
					e2.printStackTrace();
				}
			}
			
			if(this.conexion !=null)
			{
				cerrarConnection(this.conexion);
			}
		}
	}
	//RF2- Registrar Cliente
		public void registrarCliente(Cliente cliente) throws Exception
		{
			
			PreparedStatement prepStmt = null;
			try
			{
				System.out.println(cliente);
				establecerConexion();
				String sql = "INSERT INTO CLIENTE(IDCLIENTE, NOMBRE)"+
						"VALUES("+cliente.getIdCliente()+","+cliente.getNombre()+")";
				System.out.println(sql);
				prepStmt= conexion.prepareStatement(sql);
				prepStmt.execute();
			} 
			catch (Exception e)
			{
				// TODO: handle exception
				System.err.println("SQLException in executing:");
				e.printStackTrace();
			}
			finally
			{
				if (prepStmt!=null)
				{
					try 
					{
						prepStmt.close();
					} 
					catch (SQLException e2) 
					{
						// TODO: handle exception
						System.err.println("SQLException in closing Stmt:");
						e2.printStackTrace();
					}
				}
				
				if(this.conexion !=null)
				{
					cerrarConnection(this.conexion);
				}
				
			}
		}
	//RF3  Registrar Restaurante 
	
		public void registrarRestaurante(Restaurante restaurant)throws Exception
		{
			
				PreparedStatement prepStmt= null;

				try 
				{
					System.out.println(restaurant);
					establecerConexion();
					String sql= "INSERT INTO RESTAURANTE(IDRESTAURANTE,NOMBRE,NOMBREREPRESENTANTE,TIPOCOMIDA,ZONA)"
							+ "VALUES("+ restaurant.getIdRestaurante()+",'"+
							restaurant.getNombre()+"','"+restaurant.getNombreRepresentante()+"','"
							+restaurant.getTipoComida()+"','"+restaurant.getZona()+")";

					System.out.println(sql);
					prepStmt=conexion.prepareStatement(sql);
					prepStmt.execute();
				} 
				catch (Exception e) 
				{
					// TODO: handle exception
					System.err.println("SQLException in executing:");
					e.printStackTrace();
				}
				finally
				{
					if(prepStmt !=null)
					{
						try {
							prepStmt.close();
						} catch (SQLException e2) 
						{
							// TODO: handle exception
							System.err.println("SQLException in closing Stmt:");
							e2.printStackTrace();
						}

					}
					if(this.conexion !=null)
					{
						cerrarConnection(this.conexion);
					}
				}

			}
		
	// RF4 Registrar Producto
		public void registrarProducto(Producto producto) throws Exception
		{
			
				PreparedStatement prepStmt = null;
				int personalisadoTraduccion;
				if(producto.isEstaPersonalizado()==true)
				{
					personalisadoTraduccion = 1;
				}
				else
				{
					personalisadoTraduccion = 0;
				}
				try 
				{
					
					System.out.println(producto);
					establecerConexion();
					String sql = "INSERT INTO PRODUCTO(IDPRODUCTO,PRECIO,ESTAPERSONALIZADO)"
							+"VALUES("+producto.getIdProducto()+","+producto.getPrecioProducto()
							+","+personalisadoTraduccion+")";
					System.out.println(sql);
					prepStmt= conexion.prepareStatement(sql);
					prepStmt.execute();
				} 
				catch (Exception e) 
				{
					// TODO: handle exception
					System.err.println("SQLException in executing:");
					e.printStackTrace();
				}
				finally
				{
					if(prepStmt !=null)
					{
						try {
							prepStmt.close();
							
						}
						catch (SQLException e2) 
						{
							// TODO: handle exception
							System.err.println("SQLException in closing Stmt:");
							e2.printStackTrace();
						}
					}
					if(this.conexion!=null)
					{
						cerrarConnection(this.conexion);
					}
				}
			}
		
	// RF5 Registrar ingrediente
	
		public void registrarIngrediente(Ingrediente pIngredinte)throws Exception
		{
		  
				PreparedStatement prepStmt = null;

				try 
				{
					System.out.println(pIngredinte);
					establecerConexion();
					String sql = "INSERT INTO INGREDIENTE(IDINGREDIENTE,NOMBRE,DESCRIPCION,TRADUCCION)"
							+"VALUES("+pIngredinte.getIdIngrediente()+"','"+pIngredinte.getNombreIngrediente()
							+"','"+pIngredinte.getDescripcion()+"','"+pIngredinte.getTraduccion()+"')";
					System.out.println(sql);
					prepStmt= conexion.prepareStatement(sql);
					prepStmt.execute();
				} 
				catch (Exception e) 
				{
					// TODO: handle exception
					System.err.println("SQLException in executing:");
					e.printStackTrace();
				}
				finally
				{
					if(prepStmt !=null)
					{
						try {
							prepStmt.close();

						}
						catch (SQLException e2) 
						{
							// TODO: handle exception
							System.err.println("SQLException in closing Stmt:");
							e2.printStackTrace();
						}
					}
					if(this.conexion!=null)
					{
						cerrarConnection(this.conexion);
					}
				}
			}
		
	//RF6 Registrar Menu
		public void registrarMenu(vos.Menu menu)throws Exception
		{
			
				PreparedStatement prepStmt = null;
				int personalisadoTraduccion;
				if(menu.isEstaPersonalisado()==true)
				{
					personalisadoTraduccion = 1;
				}
				else
				{
					personalisadoTraduccion = 0;
				}
				try 
				{
					
					System.out.println(menu);
					establecerConexion();
					
					String sql = "INSERT INTO MENU(IDMENU,NOMBRE,PRECIO,ESTAPERSONALISADO,IDRESTAURENTE)"
							+"VALUES("+menu.getIdMenu()+","+menu.getNombre()
							+","+menu.getPrecio()+","+personalisadoTraduccion
							+menu.getIdRestaurante()+")";
					System.out.println(sql);
					prepStmt= conexion.prepareStatement(sql);
					prepStmt.execute();
				} 
				catch (Exception e) 
				{
					// TODO: handle exception
					System.err.println("SQLException in executing:");
					e.printStackTrace();
				}
				finally
				{
					if(prepStmt !=null)
					{
						try {
							prepStmt.close();
							
						}
						catch (SQLException e2) 
						{
							// TODO: handle exception
							System.err.println("SQLException in closing Stmt:");
							e2.printStackTrace();
						}
					}
					if(this.conexion!=null)
					{
						cerrarConnection(this.conexion);
					}
				}
		
		}
	//RF7 Registrar zona
	
	public void registrarZona(Zona pZona)throws Exception
	{
		PreparedStatement prepStmt= null;
		
		try 
		{
			System.out.println(pZona);
			establecerConexion();
			String sql = "INSERT INTO ZONA(NUMEROZONA,CAPACIDAD,ABIERTO,APTO,DESCRIPCION)"
					+"VALUES("+pZona.getNumeroZona()+"','"+pZona.getCapacidad()
					+"','"+pZona.getAbierto()+"','"+pZona.getApto()+"','"+pZona.getDescripcion()+"')";
			System.out.println(sql);
			prepStmt=conexion.prepareStatement(sql);
			prepStmt.execute();
		} 
		catch (Exception e) 
		{
			// TODO: handle exception
			System.err.println("SQLException in executing:");
			e.printStackTrace();
		}
		finally {
			if(prepStmt !=null)
			{
				try {
					prepStmt.close();
					
				}
				catch (SQLException e2) 
				{
					// TODO: handle exception
					System.err.println("SQLException in closing Stmt:");
					e2.printStackTrace();
				}
			}
			if(this.conexion!=null)
			{
				cerrarConnection(this.conexion);
			}
		}
	}
	//RF8 Registrar Preferencia Del Cliente
	public void registrarPreferencia(Cliente cliente)throws Exception
	{
		PreparedStatement prepStmt= null;
		
		try 
		{
			System.out.println(cliente);
			establecerConexion();
			String nuevaPreferencia = cliente.getPreferencia();
			String sql = "UPDATE CLIENTE SET PREFERENCIA="+nuevaPreferencia+"WHERE IDCLIENTE ="+cliente.getIdCliente();
					
			System.out.println(sql);
			prepStmt=conexion.prepareStatement(sql);
			prepStmt.execute();
		} 
		catch (Exception e) 
		{
			// TODO: handle exception
			System.err.println("SQLException in executing:");
			e.printStackTrace();
		}
		finally {
			if(prepStmt !=null)
			{
				try {
					prepStmt.close();
					
				}
				catch (SQLException e2) 
				{
					// TODO: handle exception
					System.err.println("SQLException in closing Stmt:");
					e2.printStackTrace();
				}
			}
			if(this.conexion!=null)
			{
				cerrarConnection(this.conexion);
			}
		}
	}
// R9 REGISTRAR PEDIDO DE UN PRODUCTO
	
	public void registrarPedidoDeUnProducto(Orden pOrden)throws Exception
	{
		PreparedStatement prepStmt=null;
		
		try 
		{
			System.out.println(pOrden);
			establecerConexion();
			Format formatofecha= new SimpleDateFormat("yyyy-MM-dd");
			java.util.Date fecha= pOrden.getFecha();
			String fechaMeter = formatofecha.format(fecha);
			String sql= "INSERT INTO ORDEN(IDORDEN,PRECIO,IDClIENTE,IDMESA,IDUSUARIO,NOMBRECLIENTE,PAGO,FECHA,HORA)"
					+"VALUES("+pOrden.getIdOrden()+","+pOrden.getPrecioTotal()+","+pOrden.getCliente()+","+pOrden.getIdMesa()
					+","+pOrden.getIdusuario()+",'"+pOrden.getNombreCliente()+"'"+", "+pOrden.getPago()+", "+"TO_DATE('"+fechaMeter+"', 'YYYY-MM-DD')"+
					","+"'"+pOrden.getHora()+"')";
			System.out.println(sql);
			prepStmt=conexion.prepareStatement(sql);
			prepStmt.execute();
		} 
		catch (Exception e)
		{
			// TODO: handle exception
			System.err.println("SQLException in executing:");
			e.printStackTrace();
		}
		finally
		{
			if(prepStmt !=null)
			{
				try {
					prepStmt.close();
					
				}
				catch (SQLException e2) 
				{
					// TODO: handle exception
					System.err.println("SQLException in closing Stmt:");
					e2.printStackTrace();
				}
			}
			if(this.conexion!=null)
			{
				cerrarConnection(this.conexion);
			}
		}
	}
	//R10 RESGISTRAR EL SERVICIO DE UN PRODUCTO
	
		public void registrarServicioDeUnProducto(Producto producto)throws Exception
		{
			PreparedStatement prepStmt=null;
			try
			{
				int idProducto = producto.getIdProducto();
				establecerConexion();
				String sql="SELECT DISPONIBLE FROM PRODUCTOS WHERE IDPRODUCTO="+idProducto;
				prepStmt= conexion.prepareStatement(sql);
				ResultSet rs= prepStmt.executeQuery();
				int disponibleActual = rs.getInt(1);
				sql = "UPDATE PRODUCTOS SET DISPONIBLE="+(disponibleActual-1)+"WHERE IDPRODUCTO="+idProducto;
				prepStmt.close();
				prepStmt=conexion.prepareStatement(sql);
				prepStmt.execute();
			}
			catch(Exception e)
			{
				System.err.println("SQLException in executing:");
				e.printStackTrace();
			}
			finally
			{
				if(prepStmt !=null)
				{
					try {
						prepStmt.close();
						
					}
					catch (SQLException e2) 
					{
						// TODO: handle exception
						System.err.println("SQLException in closing Stmt:");
						e2.printStackTrace();
					}
				}
				if(this.conexion!=null)
				{
					cerrarConnection(this.conexion);
				}
			}
		}
	
	
	//Requerimientos de consulta
	
	//RFC1 CONSULTAR LOS PRODUCTOS SERVIDOS EN ROTONDANDES 
	
	public ArrayList<Producto> consultarProductosServidosEnRotonAndes(Integer IdProducto)throws Exception
	{
		PreparedStatement prepStmt= null;
		
		try
		{
			
			establecerConexion();
			String sql="SELECT * FROM PRODUCTO WHERE IDPRODUCTO="+IdProducto;
			
			prepStmt= conexion.prepareStatement(sql);
			
			ResultSet rs= prepStmt.executeQuery();
			
			ArrayList<Producto> productos= new ArrayList<Producto>();
			
			while(rs.next())
			{	
				Producto prod= new Producto(rs.getInt("IDPRODUCTO"),rs.getString("NOMBRE"), rs.getDouble("PRECIOPRODUCTO"),
						rs.getDouble("COSTOPRODUCTO"), rs.getString("DESCRIPESP"), rs.getString("DESCRIPING"), rs.getInt("TIEMPOPREPARACION")
						, rs.getBoolean("ESTAPERSONALIZADO"), rs.getString("TIPOPRODUCTO"), rs.getInt("DISPONIBILIDAD"), rs.getInt("UNIDADESVENDIDAS"));
				productos.add(prod);
				
			}
			System.out.println(productos.isEmpty());
			return productos;
		} 
		catch (Exception e) 
		{
			// TODO: handle exception
			System.err.println("QLException in executing:");
			e.printStackTrace();
			throw e;
		}
		finally
		{
			if(prepStmt!=null)
			{
				try 
				{
					prepStmt.close();
				} 
				catch (SQLException exception) 
				{
					// TODO: handle exception
					System.err.println("SQLException in closing Stmt:");
					exception.printStackTrace();
					throw exception;
				}
			}
			if(this.conexion !=null)
			{
				cerrarConnection(this.conexion);
			}
		}
	}
	//RFC2 	CONSULTAR UNA ZONA
		public Zona consultarZona(Integer numeroZona)throws Exception
		{
			Zona zona = null;
			PreparedStatement prepStmt= null;
			try
			{
				establecerConexion();
				String sql="SELECT * FROM ZONA WHERE IDZONA="+numeroZona;
				prepStmt= conexion.prepareStatement(sql);
				ResultSet rs= prepStmt.executeQuery();
				while(rs.next())
				{
					zona = new Zona(numeroZona, numeroZona, false, false, sql);
					zona.setNumeroZona(rs.getInt(1));
					zona.setCapacidad(rs.getInt(2));
					zona.setAbierto(intABoolean(rs.getInt(3)));
					zona.setApto(intABoolean(rs.getInt(3)));
					zona.setDescripcion(rs.getString(4));
				}
				
				return zona;
			} 
			catch (SQLException e) 
			{
				// TODO: handle exception
				System.err.println("QLException in executing:");
				e.printStackTrace();
				throw e;
			}
			finally
			{
				if(prepStmt!=null)
				{
					try 
					{
						prepStmt.close();
					} 
					catch (SQLException exception) 
					{
						// TODO: handle exception
						System.err.println("SQLException in closing Stmt:");
						exception.printStackTrace();
						throw exception;
					}
				}
				if(this.conexion !=null)
				{
					cerrarConnection(this.conexion);
				}
			}

		}
		private boolean intABoolean(int pasar)
		{
			if(pasar==1)
			{
				return true;
			}
			else
				return false;
		}
//RFC3 CONSULTAR LOS CLIENTES	
	public ArrayList<Cliente> consultarClientes(Integer idCliente)throws Exception
	{
		PreparedStatement prepStmt= null;
		
		try {
			establecerConexion();
			String sql= "SELECT * FROM CLIENTE WHERE IDCLIENTE="+idCliente;
			prepStmt= conexion.prepareStatement(sql);
			ResultSet rs= prepStmt.executeQuery();
			ArrayList<Cliente> clientes= new ArrayList<Cliente>();
			while(rs.next())
			{
				Cliente cl= new Cliente(rs.getString("NOMBRE"),rs.getInt("IDCLIENTE"),rs.getString("PREFERENCIA"));
				clientes.add(cl);
			}
			
			return clientes;
		} 
		catch (SQLException e) 
		{
			// TODO: handle exception
			System.err.println("SQLException in executing:");
			e.printStackTrace();
			throw e;
		}
		finally
		{
			if(prepStmt!=null)
			{
				try 
				{
					prepStmt.close();
				} 
				catch (SQLException exception) 
				{
					// TODO: handle exception
					System.err.println("SQLException in closing Stmt:");
					exception.printStackTrace();
					throw exception;
				}
			}
			if(this.conexion !=null)
			{
				cerrarConnection(this.conexion);
			}
		}
		

	}
	//RFC4 OBTENER LOS PRODUCTOS MAS OFRECIDOS
		public ArrayList<Producto> productosMasOfrecidos()throws Exception
		{
	PreparedStatement prepStmt= null;
			
			try {
				establecerConexion();
				String sql= "SELECT * FROM PRODUCTO WHERE IDPRODCUTO=(SELECT IDPRODUCTO FROM MENU "
						+ "GROUP BY IDPRODUCTO HAVING COUNT(IDPRODUCTO)=(SELECT MAX(TOTAL) FROM"
						+ "(SELECT COUNT(IDPRODUCTO) AS TOTAL FROM MENU GROUP BY IDPRODUCTO)))";
				prepStmt= conexion.prepareStatement(sql);
				ResultSet rs= prepStmt.executeQuery();
				ArrayList<Producto> productos= new ArrayList<Producto>();
				while(rs.next())
				{
					Producto producto = new Producto(rs.getInt(1), rs.getString(2), rs.getDouble(3), 
							rs.getDouble(4), rs.getString(5), rs.getString(6), rs.getInt(7), intABoolean(rs.getInt(8)),
							rs.getString(9), rs.getInt(10), rs.getInt(11));
					productos.add(producto);
				}
				
				return productos;
			} 
			catch (SQLException e) 
			{
				// TODO: handle exception
				System.err.println("SQLException in executing:");
				e.printStackTrace();
				throw e;
			}
			finally
			{
				if(prepStmt!=null)
				{
					try 
					{
						prepStmt.close();
					} 
					catch (SQLException exception) 
					{
						// TODO: handle exception
						System.err.println("SQLException in closing Stmt:");
						exception.printStackTrace();
						throw exception;
					}
				}
				if(this.conexion !=null)
				{
					cerrarConnection(this.conexion);
				}
			}
			
		}
//RFC5 CONSULTAR RENTABILIDAD DE UN RESTAURANTE
	
	public ArrayList<Restaurante> consultarRentabilidadRestaurante(Integer idRestaurante)throws Exception
	{
		PreparedStatement prepStmt=null;
		int numProdVendidos=0;
		int costoTotal=0;
		int valorFacturado=0;
		
		try 
		{
			establecerConexion();
			String sql = "SELECT * FROM RESTAURANTE WHERE IDRESTAURANTE="+idRestaurante;
			prepStmt= conexion.prepareStatement(sql);
			ResultSet rs=prepStmt.executeQuery();
			ArrayList<Restaurante> restaurantes= new ArrayList<Restaurante>();
			while(rs.next())
			{	
				Restaurante res= new Restaurante(rs.getString("NOMBRE"), rs.getInt("IDRESTAURANTE"),
						rs.getString("NOMBREREPRESENTANTE"), rs.getString("TIPOCOMIDA"));
				numProdVendidos+= rs.getInt("NUMPRODUCTOSVENDIDOS");

				
				restaurantes.add(res);
			}
			return restaurantes;
		} 
		catch (SQLException e) {
			// TODO: handle exception
			System.err.println("SQLException in executing:");
			e.printStackTrace();
			throw e;
		}
		finally
		{
			if(prepStmt!=null)
			{
				try 
				{
					prepStmt.close();
				} 
				catch (SQLException exception) 
				{
					// TODO: handle exception
					System.err.println("SQLException in closing Stmt:");
					exception.printStackTrace();
					throw exception;
				}
			}
			if(this.conexion !=null)
			{
				cerrarConnection(this.conexion);
			}
		}
	}
	//RFC6 OBTENER LOS DATOS DE LOS PRODUCTOS MAÌ�S VENDIDOS
		public ArrayList<Producto> productosMasvendidos()throws Exception
		{
			PreparedStatement prepStmt= null;
			
			try {
				establecerConexion();
				String sql= "SELECT * FROM PRODUCTO WHERE IDPRODCUTO=(SELECT IDPRODUCTO FROM PRODUCTO "
						+ "WHERE COUNT(UNIDADESVENDIDAS)=(SELECT MAX(TOTAL) FROM"
						+ "(SELECT COUNT(UNIDADESVENDIDAS) AS TOTAL FROM PRODUCTO )))";
				prepStmt = conexion.prepareStatement(sql);
				ResultSet rs= prepStmt.executeQuery();
				ArrayList<Producto> productos= new ArrayList<Producto>();
				while(rs.next())
				{
					Producto producto = new Producto(rs.getInt(1), rs.getString(2), rs.getDouble(3), 
							rs.getDouble(4), rs.getString(5), rs.getString(6), rs.getInt(7), intABoolean(rs.getInt(8)),
							rs.getString(9), rs.getInt(10), rs.getInt(11));
					productos.add(producto);
				}
				
				return productos;
			} 
			catch (SQLException e) 
			{
				// TODO: handle exception
				System.err.println("SQLException in executing:");
				e.printStackTrace();
				throw e;
			}
			finally
			{
				if(prepStmt!=null)
				{
					try 
					{
						prepStmt.close();
					} 
					catch (SQLException exception) 
					{
						// TODO: handle exception
						System.err.println("SQLException in closing Stmt:");
						exception.printStackTrace();
						throw exception;
					}
				}
				if(this.conexion !=null)
				{
					cerrarConnection(this.conexion);
				}
			}
		}
		//iteracion 3: Requerimientos funcionales
				//RF11 REGISTRAR EQUIVALENCIA DE INGREDIENTES 	
				public void registrarEquivalenciaIngrediente(Ingrediente solicita, Ingrediente equivalente) throws Exception
				{
					PreparedStatement prepStmt = null;
					try
					{
						establecerConexion();
						String sql = "INSERT INTO EquivalenciaIngredientes(idIngrediente1, idIngrediente2) Values("+solicita.getIdIngrediente()+", "+equivalente.getIdIngrediente()+")";
						prepStmt = conexion.prepareStatement(sql);
						prepStmt.execute();
					}
					catch (SQLException e) 
					{
						// TODO: handle exception
						System.err.println("SQLException in executing:");
						e.printStackTrace();
						throw e;
					}
					finally
					{
						if(prepStmt!=null)
						{
							try 
							{
								prepStmt.close();
							} 
							catch (SQLException exception) 
							{
								// TODO: handle exception
								System.err.println("SQLException in closing Stmt:");
								exception.printStackTrace();
								throw exception;
							}
						}
						if(this.conexion !=null)
						{
							cerrarConnection(this.conexion);
						}

					}
				}
				//RF12 REGISTRAR EQUIVALENCIA DE PRODUCTOS
				public void registrarEquivalenciaProductos(Producto prod,Producto equivalente) throws Exception
				{
					PreparedStatement prepStmt= null;
					try 
					{
						establecerConexion();
						String sql="INSERT INTO EQUIVALENCIAPRODUCTOS (IDPRODUCTO1,IDPRODUCTO2) "
								+ "VALUES ("+prod.getIdProducto()+","+equivalente.getIdProducto()+")";
						prepStmt=conexion.prepareStatement(sql);
						prepStmt.execute();
						
					}
					catch (SQLException e) 
					{
						// TODO: handle exception
						System.err.println("SQLException in executing:");
						e.printStackTrace();
						throw e;
					}
					finally
					{
						if(prepStmt !=null)
						{
							try 
							{
								prepStmt.close();
							}
							catch (Exception e2) 
							{
								// TODO: handle exception
								System.err.println("SQLException in closing Stmt:");
								e2.printStackTrace();
								throw e2;
							}
						}
						if(this.conexion!=null)
						{
							cerrarConnection(this.conexion);
						}
					}
				}
				//RF13 SURTIR RESTAURANTE
				public void surtirRestaurante(Restaurante restaurante) throws Exception
				{
					PreparedStatement prepStmt = null;
					try
					{
						
						establecerConexion();
						String sql = "UPDATE Restaurante SET productosDisponibles="+restaurante.getCapacidadMaxima()+"WHERE idRestaurante="
								+ restaurante.getIdRestaurante();
						prepStmt = conexion.prepareStatement(sql);
						prepStmt.execute();
						restaurante.setProductosDisponibles(restaurante.getCapacidadMaxima());
					}
					catch (SQLException e) 
					{
						// TODO: handle exception
						System.err.println("SQLException in executing:");
						e.printStackTrace();
						throw e;
					}
					finally
					{
						if(prepStmt!=null)
						{
							try 
							{
								prepStmt.close();
								
							} 
							catch (SQLException exception) 
							{
								// TODO: handle exception
								System.err.println("SQLException in closing Stmt:");
								exception.printStackTrace();
								throw exception;
							}
						}
						if(this.conexion !=null)
						{
							cerrarConnection(this.conexion);
						}

					}
				}
				//RF14 REGISTRAR PEDIDO DE UN PRODUCTO – CON EQUIVALENCIAS
				public void registrarPedidoProductoEquivalencias(Orden pOrden) throws Exception
				{
					PreparedStatement prepStmt=null;
					
					try 
					{
						establecerConexion();
						ArrayList<Integer> menus= pOrden.getMenu();
						String sql= "SELECT IDORDEN FROM ORDEN";
						prepStmt= conexion.prepareStatement(sql);
						
						
						registrarPedidoDeUnProducto(pOrden);
						int idOrden= pOrden.getIdOrden();
						for (int i = 0; i < menus.size(); i++) 
						{
							Integer menuOrden= menus.get(i);
							sql="INSERT INTO TABLE ORDEN (IDORDEN, PRECIO,IDMESA,IDUSUARIO,NOMBRECLIENTE,PAGO,IDMENU,FECHA,HORA,ESTASERVIDO) VALUES ("+
									idOrden+","+pOrden.getPrecioTotal()+","+pOrden.getIdMesa()+","+pOrden.getIdusuario()+","+pOrden.getNombreCliente()+","+pOrden.getPago()+","+pOrden.getMenu()+","+pOrden.getFecha()+","+pOrden.getHora()+","+pOrden.isEstaServido()+") WHERE ORDEN.IDPRODUCTO = EQUIVALENCIAPRODUCTOS.IDPRODUCTO1";
							prepStmt.execute();
							
							sql="INSERT INTO TABLE EQUIVALENCIAPRODUCTOS (IDPRODUCTO1,IDPRODUCTO2) VALUES ("+pOrden.getIdOrden()+","+pOrden.getIdOrden()+")";
							prepStmt.execute();
						}
						
						
					}
					catch (SQLException e) 
					{
						// TODO: handle exception
						System.err.println("SQLException in executing:");
						e.printStackTrace();
						throw e;
					}
					finally
					{
						if(prepStmt!=null)
						{
							try 
							{
								prepStmt.close();
								
							} 
							catch (SQLException exception) 
							{
								// TODO: handle exception
								System.err.println("SQLException in closing Stmt:");
								exception.printStackTrace();
								throw exception;
							}
						}
						if(this.conexion !=null)
						{
							cerrarConnection(this.conexion);
						}

					}
				}
				//RF15 REGISTRAR PEDIDO DE PRODUCTOS DE UNA MESA
				public void registrarPedidoProductoMesa(Orden orden) throws Exception
				{
					PreparedStatement prepStmt = null;
					try
					{
						establecerConexion();
						ArrayList<Integer> menus = orden.getMenu();
						String sql = "SELECT idOrden FROM ORDEN";
						System.out.println("conexion.getAutoCommit();");
						
						prepStmt=conexion.prepareStatement(sql);
						
						
						
						registrarPedidoDeUnProducto(orden);
						int idOrden = orden.getIdOrden();
						for (int i = 0; i < menus.size(); i++) {
							Integer menuActual = menus.get(i);
							
							sql = "INSERT INTO ordenMenus (idOrden, idMenu) VALUES ("+idOrden+", "+menuActual+")";
							prepStmt.execute(sql);
						}
					}
					catch (SQLException e) 
					{
						// TODO: handle exception
						System.err.println("SQLException in executing:");
						e.printStackTrace();
						throw e;
					}
					finally
					{
						
						if(prepStmt!=null)
						{
							try 
							{
								String sqlCommit = "COMMIT";
								prepStmt.execute(sqlCommit);
					
								prepStmt.close();
							} 
							catch (SQLException exception) 
							{
								// TODO: handle exception
								String sqlRollback = "ROLLBACK";
								prepStmt.execute(sqlRollback);
								System.err.println("SQLException in closing Stmt:");
								exception.printStackTrace();
								throw exception;
							}
						}
						if(this.conexion !=null)
						{
							cerrarConnection(this.conexion);
						}

					}
				}
				//RF16 REGISTRAR EL SERVICIO DE UNA MESA
				public void registrarServicioMesa(Orden pOrden, Producto prod) throws Exception
				{
					PreparedStatement prepStmt= null;
					
					try 
					{
						establecerConexion();
						ArrayList<Integer> productos= pOrden.getMenu();
						String sql="SELECT IDORDEN FROM ORDEN";
						prepStmt= conexion.prepareStatement(sql);
						
						registrarPedidoDeUnProducto(pOrden);
						int idOrden= pOrden.getIdOrden();
						for (int i = 0; i < productos.size(); i++) 
						{
							Integer menuActal= productos.get(i);
							sql="INSERT INTO ORDEN (IDORDEN, PRECIO,IDMESA,IDUSUARIO,NOMBRECLIENTE,PAGO,IDMENU,FECHA,HORA,ESTASERVIDO) VALUES ("+idOrden+","
							+pOrden.getPrecioTotal()+","+pOrden.getIdMesa()+","+pOrden.getIdusuario()+","+pOrden.getNombreCliente()+","+pOrden.getPago()+","+pOrden.getMenu()+","+pOrden.getFecha()+","+pOrden.getHora()+","+pOrden.isEstaServido()+")";
							prepStmt.execute();
							
							sql="UPDATE PRODUCTO SET DISPONIBILIDAD = "+prod.aumentarDisponibilidad();
							prepStmt.execute();
							
						}
						
					}
					catch (Exception e) 
					{
						// TODO: handle exception
						System.err.println("SQLException in executing:");
						e.printStackTrace();
						throw e;
					}
					finally 
					{
						if(prepStmt!=null)
						{
							try 
							{
								String sqlCommit = "COMMIT";
								prepStmt.execute(sqlCommit);
					
								prepStmt.close();
							} 
							catch (SQLException exception) 
							{
								// TODO: handle exception
								String sqlRollback = "ROLLBACK";
								prepStmt.execute(sqlRollback);
								System.err.println("SQLException in closing Stmt:");
								exception.printStackTrace();
								throw exception;
							}
						}
						if(this.conexion !=null)
						{
							cerrarConnection(this.conexion);
						}

					}
					
				}
				//RF17 CANCELAR PEDIDO
				public void cancelarPedido(Orden pOrden) throws Exception
				{
					PreparedStatement prepStmt = null;
					try
					{
						
						establecerConexion();
						if(!pOrden.isEstaServido())
						{
						String sql = "DELETE FROM Pago WHERE idOrden="+ pOrden.getIdOrden();
						prepStmt = conexion.prepareStatement(sql);
						prepStmt.executeQuery();
						sql = "DELETE FROM ordenMenus WHERE idOrden="+ pOrden.getIdOrden();
						prepStmt.executeQuery(sql);
						sql = "DELETE FROM orden WHERE idOrden="+ pOrden.getIdOrden();
						prepStmt.executeQuery(sql);
						}
						else
						{
							Exception e = new Exception();
						}
						
					}
					catch (SQLException e) 
					{
						// TODO: handle exception
						System.err.println("SQLException in executing:");
						e.printStackTrace();
						throw e;
					}
					catch(Exception e1)
					{
						System.err.println("no se puede cancelar el pedido");
						e1.printStackTrace();
						throw e1;
					}
					finally
					{
						if(prepStmt!=null)
						{
							try 
							{
								prepStmt.close();
								
							} 
							catch (SQLException exception) 
							{
								// TODO: handle exception
								System.err.println("SQLException in closing Stmt:");
								exception.printStackTrace();
								throw exception;
							}
						}
						if(this.conexion !=null)
						{
							cerrarConnection(this.conexion);
						}

					}
				}
		//Iteracion 3: Requerimientos de busqueda
			//RFC7 Administrador: CONSULTAR EL CONSUMO DE UN CLIENTE REGISTRADO
			public ArrayList<Producto> consultarConsumoClienteAdministrador(int clienteConsutado)throws Exception
			{
				
				PreparedStatement prepStmt = null;
				try
				{
					
					establecerConexion();
					ArrayList<Producto> productosConsumidos = new ArrayList<Producto>();
					String sql = "SELECT idMenu FROM Orden WHERE idCliente="+clienteConsutado+"GROUP BY idMenu";
					prepStmt = conexion.prepareStatement(sql);
					ResultSet rs = prepStmt.executeQuery();
					while(rs.next())
					{
						int menuActual = rs.getInt("idMenu");
						sql = "SELECT idProducto FROM ProductosMenu WHERE idMenu="+menuActual+"GROUP BY idProducto";
						ResultSet rs2 = prepStmt.executeQuery(sql);
						while(rs2.next())
						{
							int idProductoActual = rs2.getInt("idProducto");
							Producto productoActual = consultarProducto(idProductoActual);
							productosConsumidos.add(productoActual);
						}
						
					}
					
					
					return productosConsumidos;
				}
				catch (SQLException e) 
				{
					// TODO: handle exception
					System.err.println("SQLException in executing:");
					e.printStackTrace();
					throw e;
				}
				finally
				{
					if(prepStmt!=null)
					{
						try 
						{
							prepStmt.close();
							
						} 
						catch (SQLException exception) 
						{
							// TODO: handle exception
							System.err.println("SQLException in closing Stmt:");
							exception.printStackTrace();
							throw exception;
						}
					}
					if(this.conexion !=null)
					{
						cerrarConnection(this.conexion);
					}

				}
			}
			private Producto consultarProducto(int idProductoActual) throws Exception{

				PreparedStatement prepStmt = null;
				try
				{
					
					establecerConexion();
					Producto producto = null;
					String sql = "SELECT * FROM Producto WHERE idProducto="+idProductoActual;
					prepStmt = conexion.prepareStatement(sql);
					ResultSet rs = prepStmt.executeQuery();
					while(rs.next())
					{
						producto = new Producto(rs.getInt("idProducto"), rs.getString("nombre"), 
								rs.getDouble("precioProducto"), rs.getDouble("costoProducto"), rs.getString("descripEsp"),
								rs.getString("descripIng"), rs.getInt("tiempoPreparacion"), intABoolean(rs.getInt("estaPersonalizado")), 
								rs.getString("tipoProducto"), rs.getInt("disponibilidad"), rs.getInt("unidadesVendidas"));
					}
					
					
					return producto;
				}
				catch (SQLException e) 
				{
					// TODO: handle exception
					System.err.println("SQLException in executing:");
					e.printStackTrace();
					throw e;
				}
				finally
				{
					if(prepStmt!=null)
					{
						try 
						{
							prepStmt.close();
							
						} 
						catch (SQLException exception) 
						{
							// TODO: handle exception
							System.err.println("SQLException in closing Stmt:");
							exception.printStackTrace();
							throw exception;
						}
					}
					if(this.conexion !=null)
					{
						cerrarConnection(this.conexion);
					}

				}
		}

			//RFC7 Cliente: CONSULTAR EL CONSUMO DE UN CLIENTE REGISTRADO
			public ArrayList<Producto> consultarConsumoClienteCliente(int idCliente)throws Exception
			{
				
				PreparedStatement prepStmt = null;
				try
				{
					
					establecerConexion();
					ArrayList<Producto> productosConsumidos = new ArrayList<Producto>();
					String sql = "SELECT idMenu FROM Orden WHERE idCliente="+idCliente+"GROUP BY idMenu";
					prepStmt = conexion.prepareStatement(sql);
					ResultSet rs = prepStmt.executeQuery();
					while(rs.next())
					{
						int menuActual = rs.getInt("idMenu");
						sql = "SELECT idProducto FROM ProductosMenu WHERE idMenu="+menuActual+"GROUP BY idProducto";
						ResultSet rs2 = prepStmt.executeQuery(sql);
						while(rs2.next())
						{
							int idProductoActual = rs2.getInt("idProducto");
							Producto productoActual = consultarProducto(idProductoActual);
							productosConsumidos.add(productoActual);
						}
						
					}
					
					
					return productosConsumidos;
				}
				catch (SQLException e) 
				{
					// TODO: handle exception
					System.err.println("SQLException in executing:");
					e.printStackTrace();
					throw e;
				}
				finally
				{
					if(prepStmt!=null)
					{
						try 
						{
							prepStmt.close();
							
						} 
						catch (SQLException exception) 
						{
							// TODO: handle exception
							System.err.println("SQLException in closing Stmt:");
							exception.printStackTrace();
							throw exception;
						}
					}
					if(this.conexion !=null)
					{
						cerrarConnection(this.conexion);
					}

				}
			}
			//RFC8 Administrador: CONSULTAR PEDIDOS
			public ArrayList<Orden> consultarPedidosAdministrador()throws Exception
			{
				PreparedStatement prepStmt=null;
				try 
				{
					establecerConexion();
					String sql="SELECT * FROM ORDEN";
					prepStmt=conexion.prepareStatement(sql);
					ResultSet rs= prepStmt.executeQuery();
					ArrayList<Orden> pedidosConsilidados= new ArrayList<>();
					while (rs.next())
					{
						Orden pOrden= new Orden(rs.getInt("IDORDEN"), rs.getInt("PRECIO"),rs.getInt("IDMESA"), rs.getInt("IDUSUARIO")
								, rs.getString("NOMBRECLIENTE"), rs.getInt("IDCLIENTE"),rs.getInt("PAGO"), rs.getDate("FECHA"),rs.getInt("HORA"));
						pedidosConsilidados.add(pOrden);
					}
					return pedidosConsilidados;
				}
				catch (SQLException e) 
				{
					// TODO: handle exception
					System.err.println("SQLException in executing:");
					e.printStackTrace();
					throw e;
				}
				finally
				{
					if(prepStmt!=null)
					{
						try 
						{
							prepStmt.close();
							
						} 
						catch (SQLException exception) 
						{
							// TODO: handle exception
							System.err.println("SQLException in closing Stmt:");
							exception.printStackTrace();
							throw exception;
						}
					}
					if(this.conexion !=null)
					{
						cerrarConnection(this.conexion);
					}

				}
				
			}
			//Pruebas Iteracion 3
			public Orden consultarOrden(int idOrden)throws Exception {
				PreparedStatement prepStmt = null;
				try
				{
					
					establecerConexion();
					Orden orden = null;
					String sql = "SELECT * FROM Orden WHERE idOrden="+idOrden;
					prepStmt = conexion.prepareStatement(sql);
					ResultSet rs = prepStmt.executeQuery();
					while(rs.next())
					{
						orden = new Orden(rs.getInt("idOrden"), rs.getInt("precio"), rs.getInt("idMesa"),
								rs.getInt("idUsuario"), rs.getString("NombreCliente"), rs.getInt("idCliente"), 
								rs.getInt("Pago"), rs.getDate("Fecha"), rs.getInt("Hora"));
						
					}
					
					
					return orden;
				}
				catch (SQLException e) 
				{
					// TODO: handle exception
					System.err.println("SQLException in executing:");
					e.printStackTrace();
					throw e;
				}
				finally
				{
					if(prepStmt!=null)
					{
						try 
						{
							prepStmt.close();
							
						} 
						catch (SQLException exception) 
						{
							// TODO: handle exception
							System.err.println("SQLException in closing Stmt:");
							exception.printStackTrace();
							throw exception;
						}
					}
					if(this.conexion !=null)
					{
						cerrarConnection(this.conexion);
					}

				}
			}
			//RFC8 Cliente: CONSULTAR PEDIDO
			public ArrayList<Orden> consultarPedido(int idCliente) throws Exception
			{
				PreparedStatement prepStmt=null;
				try 
				{
					establecerConexion();
					String sql= "SELECT * FROM ORDEN WHERE IDCLIENTE= "+idCliente;
					prepStmt=conexion.prepareStatement(sql);
					ResultSet rs=prepStmt.executeQuery();
					ArrayList<Orden> ordenCliente= new ArrayList<>();
					while(rs.next())
					{
						Orden pOrden= new Orden(idCliente, rs.getInt("PRECIO"),rs.getInt("IDMESA"), rs.getInt("IDUSUARIO")
								, rs.getString("NOMBRECLIENTE"), rs.getInt("IDCLIENTE"),rs.getInt("PAGO"), rs.getDate("FECHA"),rs.getInt("HORA"));
						ordenCliente.add(pOrden);
					}
					return ordenCliente;
					
				}
				catch (SQLException e) 
				{
					// TODO: handle exception
					System.err.println("SQLException in executing:");
					e.printStackTrace();
					throw e;
				}
				finally
				{
					if(prepStmt!=null)
					{
						try 
						{
							prepStmt.close();
							
						} 
						catch (SQLException exception) 
						{
							// TODO: handle exception
							System.err.println("SQLException in closing Stmt:");
							exception.printStackTrace();
							throw exception;
						}
					}
					if(this.conexion !=null)
					{
						cerrarConnection(this.conexion);
					}

				}
				
			}
	//Iteracion 4 poblar tablas:
			public void llenarTablaCliente()throws Exception
			{
				PreparedStatement prepStmt= null;
				int cuanto=35000000;
				try
				{
					
					establecerConexion();
					String sql = "SELECT * FROM RESERVA WHERE IDRESERVA=1";
					
					prepStmt= conexion.prepareStatement(sql);
					int idCliente=916672;
					String nombre="Cliente";
					Random r = new Random();
					
					for (int i = 0; i < cuanto; i++) {
						idCliente=idCliente+1;
						sql="INSERT INTO CLIENTE(IDCLIENTE,NOMBRE,PREFERENCIA,REGISTRADO)"+
					" VALUES("+(idCliente)+","+"'"+(nombre+i)+"'"+","+"'"+preferenciaActual(r)+"'"+","+boleanAInt(r.nextBoolean())+")";
						
						prepStmt.execute(sql);
						System.out.println(i);
					}
					
					
				} 
				catch (Exception e)
				{
					// TODO: handle exception
					System.err.println("SQLException in executing:");
					e.printStackTrace();
				}
				finally
				{
					if (prepStmt!=null)
					{
						try 
						{
							prepStmt.close();
						} 
						catch (SQLException e2) 
						{
							// TODO: handle exception
							System.err.println("SQLException in closing Stmt:");
							e2.printStackTrace();
						}
					}
					
					if(this.conexion !=null)
					{
						cerrarConnection(this.conexion);
					}
				}
				
			}

			private String preferenciaActual(Random r) {
				int cual = r.nextInt(5)%5;
				String preferencia=null;
				if(cual==0)
				{
					preferencia="ACOMPANAMIENTO";
				}
				else if(cual==1)
				{
					preferencia="BEBIDAS";
				}
				else if(cual==2)
				{
					preferencia="ENTRADA";
				}
				else if(cual==3)
				{
					preferencia="PLATOFUERTE";
				}
				else
				{
					preferencia="POSTRE";
				}
				return preferencia;
			}

			private int boleanAInt(boolean nextBoolean) {
				int resultado = -1;
				if(nextBoolean)
				{
					resultado = 1;
				}
				else
				{
					resultado=0;
				}
				return resultado;
			}

			public void llenarTablaIngrediente()throws Exception
			{
				PreparedStatement prepStmt= null;
				int cuanto=2;
				try
				{
					
					establecerConexion();
					String sql = "SELECT * FROM RESERVA WHERE IDRESERVA=1";
					System.out.println(sql);
					prepStmt= conexion.prepareStatement(sql);
					int idIngrediente=100;
					String nombre="Ingrediente";
					Random r = new Random();
					String descripcion="Descripcion ";
					String traduccion = "Description ";
					for (int i = 0; i < cuanto; i++) {
						idIngrediente = idIngrediente+1;
						
						sql="INSERT INTO INGREDIENTE(IDINGREDIENTE,NOMBRE,DESCRIPCION,TRADUCCION)"+
					" VALUES("+(idIngrediente)+","+"'"+(nombre+i)+"'"+","+"'"+(descripcion+r.nextInt(2017))+"'"+","+"'"+
								(traduccion+r.nextInt(1000))+"'"+")";
						
						prepStmt.execute(sql);
						if(i%1000==1000)
						{
						System.out.println(i);
						}
					}
					
					
				} 
				catch (Exception e)
				{
					// TODO: handle exception
					System.err.println("SQLException in executing:");
					e.printStackTrace();
				}
				finally
				{
					if (prepStmt!=null)
					{
						try 
						{
							prepStmt.close();
						} 
						catch (SQLException e2) 
						{
							// TODO: handle exception
							System.err.println("SQLException in closing Stmt:");
							e2.printStackTrace();
						}
					}
					
					if(this.conexion !=null)
					{
						cerrarConnection(this.conexion);
					}
				}
			}
			public void llenarTablaMenu()throws Exception
			{
				PreparedStatement prepStmt= null;
				int cuanto=2;
				try
				{
					
					establecerConexion();
					String sql = "SELECT * FROM RESERVA WHERE IDRESERVA=1";
					System.out.println(sql);
					prepStmt= conexion.prepareStatement(sql);
					int idMenu=100;
					int idProducto=20;
					int idRestaurante=1;
					String nombre="Menu ";
					Random r = new Random();
					
					for (int i = 0; i < cuanto; i++) {
						idMenu = idMenu+1;
						idProducto=idProducto+1;
						idRestaurante=idRestaurante+1;
						sql="INSERT INTO MENU(IDMENU,NOMBRE,IDPRODUCTO,PRECIO,COSTO,ESTAPERZONALIZADO,IDRESTAURANTE)"+
					" VALUES("+(idMenu)+","+"'"+(nombre+i)+"'"+","+idProducto+","+","+r.nextInt(500)+","+r.nextInt(500)+
					","+boleanAInt(r.nextBoolean())+","+idRestaurante+")";
						
						prepStmt.execute(sql);
						if(i%1000==1000)
						{
						System.out.println(i);
						}
					}
					
					
				} 
				catch (Exception e)
				{
					// TODO: handle exception
					System.err.println("SQLException in executing:");
					e.printStackTrace();
				}
				finally
				{
					if (prepStmt!=null)
					{
						try 
						{
							prepStmt.close();
						} 
						catch (SQLException e2) 
						{
							// TODO: handle exception
							System.err.println("SQLException in closing Stmt:");
							e2.printStackTrace();
						}
					}
					
					if(this.conexion !=null)
					{
						cerrarConnection(this.conexion);
					}
				}
			}
			public void llenarTablaOrden()throws Exception
			{
				PreparedStatement prepStmt= null;
				int cuanto=2;
				try
				{
					
					establecerConexion();
					String sql = "SELECT * FROM RESERVA WHERE IDRESERVA=1";
					
					prepStmt= conexion.prepareStatement(sql);
					int idOrden=100;
					String nombreCliente="Cliente";
					int idCliente=10;
					int idMenu=20;
					int idMesa=30;
					int idUsuario=40;
					int idRestaurante=50;
					
					Random r = new Random();
					int[] anios = r.ints(2010, 2017).toArray();
					int[] meses = r.ints(1, 12).toArray();
					int[] dias = r.ints(1, 30).toArray();
					int aniosTam = anios.length;
					int mesesTam = meses.length;
					int diasTam = dias.length;
					for (int i = 0; i < cuanto; i++) {
						idCliente=idCliente+1;
						idMenu = idMenu+1;
						idMesa=idMesa+1;
						idUsuario=idUsuario+1;
						idRestaurante=idRestaurante+1;
						idOrden=idOrden+1;
						int anio = anios[r.nextInt(aniosTam)];
						int mes = meses[r.nextInt(mesesTam)];
						int dia = dias[r.nextInt(diasTam)];
						
						Date fecha = new Date(anio, mes, dia);
						sql="INSERT INTO ORDEN(IDORDEN,PRECIO,IDCLIENTE,IDMENU,IDMESA,IDUSUARIO,NOMBRECLIENTE,PAGO,FECHA,"
								+ "HORA,ESTASERVIDO,VENTA,IDERESTAURANTE)"+
					" VALUES("+(idOrden)+","+r.nextInt(500)+","+idCliente+","+idMenu+","+idMesa+","+idUsuario+","+(nombreCliente+i)+","+
								r.nextInt(500)+","+fecha+","+r.nextInt(2400)+","+boleanAInt(r.nextBoolean())+","+r.nextInt(500)+","+idRestaurante+")";
						
						prepStmt.execute(sql);
						if(i%1000==1000)
						{
						System.out.println(i);
						}
					}
					
					
				} 
				catch (Exception e)
				{
					// TODO: handle exception
					System.err.println("SQLException in executing:");
					e.printStackTrace();
				}
				finally
				{
					if (prepStmt!=null)
					{
						try 
						{
							prepStmt.close();
						} 
						catch (SQLException e2) 
						{
							// TODO: handle exception
							System.err.println("SQLException in closing Stmt:");
							e2.printStackTrace();
						}
					}
					
					if(this.conexion !=null)
					{
						cerrarConnection(this.conexion);
					}
				}
			}
			public void llenarTablaPago()throws Exception
			{
				PreparedStatement prepStmt= null;
				int cuanto=2;
				try
				{
					
					establecerConexion();
					String sql = "SELECT * FROM RESERVA WHERE IDRESERVA=1";
					
					prepStmt= conexion.prepareStatement(sql);
					int idPago=100;
					
					
					int idCliente = 50;
					String tipoPago = "Pago ";
					int idOrden = 60;
					for (int i = 0; i < cuanto; i++) {
						idPago=idPago+1;
						idCliente=idCliente+1;
						idOrden=idOrden+1;
						sql="INSERT INTO PAGO(IDPAGO,IDCLIENTE,TIPOPAGO,IDORDEN)"+
					" VALUES("+(idPago)+","+idCliente+"'"+(tipoPago+i)+"'"+","+idOrden+")";
						System.out.println(sql);
						prepStmt.execute(sql);
						if(i%1000==1000)
						{
						System.out.println(i);
						}
					}
					
					
				} 
				catch (Exception e)
				{
					// TODO: handle exception
					System.err.println("SQLException in executing:");
					e.printStackTrace();
				}
				finally
				{
					if (prepStmt!=null)
					{
						try 
						{
							prepStmt.close();
						} 
						catch (SQLException e2) 
						{
							// TODO: handle exception
							System.err.println("SQLException in closing Stmt:");
							e2.printStackTrace();
						}
					}
					
					if(this.conexion !=null)
					{
						cerrarConnection(this.conexion);
					}
				}
			}
			public void llenarTablaProducto()throws Exception
			{
				PreparedStatement prepStmt= null;
				int cuanto=2;
				try
				{
					
					establecerConexion();
					String sql = "SELECT * FROM RESERVA WHERE IDRESERVA=1";
					
					prepStmt= conexion.prepareStatement(sql);
					int idProducto=100;
					String nombre="Producto ";
					String tipoProducto = "Tipo ";
					String descrip= "Descripcion ";
					String traduccion = "Description ";
					Random r = new Random();
					
					for (int i = 0; i < cuanto; i++) {
						idProducto= idProducto+1;
						sql="INSERT INTO PRODUCTO(IDPRODUCTO,NOMBRE,PRECIOPRODUCTO,ESTAPERSONALIZADO,TIPOPRODUCTO"
								+ "COSTOPRODUCTO,DESCRIPESP,DESCRIPING,TIEMPOPREPARACION,ESTAPERZONALIZADO,DISPONIBILIDAD,UNIDADESVENDIDAS)"+
					" VALUES("+(idProducto)+","+"'"+(nombre+i)+"'"+","+r.nextInt(500)+","+boleanAInt(r.nextBoolean())+","+tipoProducto+r.nextInt(100)+","
								+r.nextInt(500)+","+descrip+","+traduccion+","+r.nextInt(100)+","+boleanAInt(r.nextBoolean())+","+r.nextInt(10000)+","+r.nextInt(10000)+")";
						
						prepStmt.execute(sql);
						if(i%1000==1000)
						{
						System.out.println(i);
						}
					}
					
					
				} 
				catch (Exception e)
				{
					// TODO: handle exception
					System.err.println("SQLException in executing:");
					e.printStackTrace();
				}
				finally
				{
					if (prepStmt!=null)
					{
						try 
						{
							prepStmt.close();
						} 
						catch (SQLException e2) 
						{
							// TODO: handle exception
							System.err.println("SQLException in closing Stmt:");
							e2.printStackTrace();
						}
					}
					
					if(this.conexion !=null)
					{
						cerrarConnection(this.conexion);
					}
				}
			}
			public void llenarTablaRestaurante()throws Exception
			{
				PreparedStatement prepStmt= null;
				int cuanto=2;
				try
				{
					
					establecerConexion();
					String sql = "SELECT * FROM RESERVA WHERE IDRESERVA=1";
					
					prepStmt= conexion.prepareStatement(sql);
					int idRestaurante=100;
					String nombre="Restaurante ";
					Random r = new Random();
					int idMenu = 10;
					String nombreRepresentante = "Representante ";
					String tipoComida = "Tipo Comida ";
					int idZona=20;
					
					for (int i = 0; i < cuanto; i++) {
						idRestaurante=idRestaurante+1;
						idMenu=idMenu+i;
						sql="INSERT INTO RESTAURANTE(IDRESTAURANTE,NOMBRE,IDMENU,NOMBREREPRESENTANTE,TIPOCOMIDA,NUMPRODUCTOSVENDIDOS,IDZONA,PRODUCTOSDISPONIBLES)"+
					" VALUES("+(idRestaurante)+","+"'"+(nombre+i)+"'"+","+idMenu+","+nombreRepresentante+i+","+tipoComida+i+","+r.nextInt(10000)+idZona+","+r.nextInt(10000)+")";
						
						prepStmt.execute(sql);
						if(i%1000==1000)
						{
						System.out.println(i);
						}
					}
					
					
				} 
				catch (Exception e)
				{
					// TODO: handle exception
					System.err.println("SQLException in executing:");
					e.printStackTrace();
				}
				finally
				{
					if (prepStmt!=null)
					{
						try 
						{
							prepStmt.close();
						} 
						catch (SQLException e2) 
						{
							// TODO: handle exception
							System.err.println("SQLException in closing Stmt:");
							e2.printStackTrace();
						}
					}
					
					if(this.conexion !=null)
					{
						cerrarConnection(this.conexion);
					}
				}
			}
			public void llenarTablaUsuario()throws Exception
			{
				PreparedStatement prepStmt= null;
				int cuanto=2;
				try
				{
					
					establecerConexion();
					String sql = "SELECT * FROM CLIENTE WHERE IDCLIENTE=1";
					
					prepStmt= conexion.prepareStatement(sql);
					int identificacion=100;
					String nombre="Usuario ";
					String correo = "@hotmail.com";
					Random r = new Random();
					
					for (int i = 0; i < cuanto; i++) {
						identificacion = identificacion+1;
						sql="INSERT INTO USUARIO(IDENTIFICACION,NOMBRE,CORREO,ROL)"+
					" VALUES("+(identificacion)+","+"'"+(nombre+i)+"'"+","+r.nextInt(100000)+correo+
					","+elegirRol(r)+")";
					
						prepStmt.execute(sql);
						if(i%1000==1000)
						{
						System.out.println(i);
						}
					}
					
					
				} 
				catch (Exception e)
				{
					// TODO: handle exception
					System.err.println("SQLException in executing:");
					e.printStackTrace();
				}
				finally
				{
					if (prepStmt!=null)
					{
						try 
						{
							prepStmt.close();
						} 
						catch (SQLException e2) 
						{
							// TODO: handle exception
							System.err.println("SQLException in closing Stmt:");
							e2.printStackTrace();
						}
					}
					
					if(this.conexion !=null)
					{
						cerrarConnection(this.conexion);
					}
				}
			}
			private String elegirRol(Random r) {
				int cual = r.nextInt(3);
				String elegi;
				if(cual==0)
				{
					elegi = "Administrador";
				}
				else if(cual==1)
				{
					elegi= "Cliente";
				}
				else if(cual==2)
				{
					elegi="Restaurante";
				}
				else
				{
					elegi = "NoRegistrado";
				}
				return elegi;
			}

			public void llenarTablaZona()throws Exception
			{
				PreparedStatement prepStmt= null;
				int cuanto=2;
				try
				{
					
					establecerConexion();
					String sql = "SELECT * FROM CLIENTE WHERE IDCLIENTE=1";
					
					prepStmt= conexion.prepareStatement(sql);
					int idZona=100;
					String descripcion="Descripcion ";
					Random r = new Random();
					
					for (int i = 0; i < cuanto; i++) {
						idZona = idZona+1;
						sql="INSERT INTO ZONA(IDZONA,CAPACIDAD,ABIERTO,APTO,DESCRIPCION)"+
					" VALUES("+(idZona)+","+r.nextInt(50000)+","+boleanAInt(r.nextBoolean())+","+boleanAInt(r.nextBoolean())+
					descripcion+")";
						
						prepStmt.execute(sql);
						if(i%1000==1000)
						{
						System.out.println(i);
						}
					}
					
					
				} 
				catch (Exception e)
				{
					// TODO: handle exception
					System.err.println("SQLException in executing:");
					e.printStackTrace();
				}
				finally
				{
					if (prepStmt!=null)
					{
						try 
						{
							prepStmt.close();
						} 
						catch (SQLException e2) 
						{
							// TODO: handle exception
							System.err.println("SQLException in closing Stmt:");
							e2.printStackTrace();
						}
					}
					
					if(this.conexion !=null)
					{
						cerrarConnection(this.conexion);
					}
				}
			}
			public void llenarTablaEquivalenciaIngredientes()throws Exception
			{
				PreparedStatement prepStmt= null;
				int cuanto=2;
				try
				{
					
					establecerConexion();
					String sql = "SELECT * FROM CLIENTE WHERE IDCLIENTE=1";
					
					prepStmt= conexion.prepareStatement(sql);
					
					
					Random r = new Random();
					
					for (int i = 0; i < cuanto; i++) {
						
						sql="INSERT INTO EquivalenciaIngredientes(IDINGREDIENTE1,IDINGREDIENTE2)"+
					" VALUES("+r.nextInt(1000000)+r.nextInt(100000)+")";
						
						prepStmt.execute(sql);
						if(i%1000==1000)
						{
						System.out.println(i);
						}
					}
					
					
				} 
				catch (Exception e)
				{
					// TODO: handle exception
					System.err.println("SQLException in executing:");
					e.printStackTrace();
				}
				finally
				{
					if (prepStmt!=null)
					{
						try 
						{
							prepStmt.close();
						} 
						catch (SQLException e2) 
						{
							// TODO: handle exception
							System.err.println("SQLException in closing Stmt:");
							e2.printStackTrace();
						}
					}
					
					if(this.conexion !=null)
					{
						cerrarConnection(this.conexion);
					}
				}
			}
			
// Iteración 4 
			
//Población tablas
		
			public void llenarTablaEquivalenciaProductos()throws Exception
			{
				PreparedStatement prepStmt= null;
				int cuanto=2;
				try
				{
					
					establecerConexion();
					String sql = "SELECT * FROM CLIENTE WHERE IDCLIENTE=1";
					
					prepStmt= conexion.prepareStatement(sql);
					
					
					Random r = new Random();
					
					for (int i = 0; i < cuanto; i++) {
						
						sql="INSERT INTO EquivalenciaProductos(IDPRODUCTO1,IDPRODUCTO2)"+
					" VALUES("+r.nextInt(1000000)+","+r.nextInt(1000000)+")";
						
						prepStmt.execute(sql);
						if(i%1000==1000)
						{
						System.out.println(i);
						}
					}
					
					
				} 
				catch (Exception e)
				{
					// TODO: handle exception
					System.err.println("SQLException in executing:");
					e.printStackTrace();
				}
				finally
				{
					if (prepStmt!=null)
					{
						try 
						{
							prepStmt.close();
						} 
						catch (SQLException e2) 
						{
							// TODO: handle exception
							System.err.println("SQLException in closing Stmt:");
							e2.printStackTrace();
						}
					}
					
					if(this.conexion !=null)
					{
						cerrarConnection(this.conexion);
					}
				}
			}
			public void llenarTablaOrdenMenus()throws Exception
			{
				PreparedStatement prepStmt= null;
				int cuanto=2;
				try
				{
					
					establecerConexion();
					String sql = "SELECT * FROM CLIENTE WHERE IDCLIENTE=1";
					
					prepStmt= conexion.prepareStatement(sql);
					
					Random r = new Random();
					
					for (int i = 0; i < cuanto; i++) {
						
						sql="INSERT INTO ORDENMENUS(IDORDEN,IDMENU)"+
					" VALUES("+r.nextInt(1000000)+","+r.nextInt(1000000)+")";
						
						prepStmt.execute(sql);
						if(i%1000==1000)
						{
						System.out.println(i);
						}
					}
					
					
				} 
				catch (Exception e)
				{
					// TODO: handle exception
					System.err.println("SQLException in executing:");
					e.printStackTrace();
				}
				finally
				{
					if (prepStmt!=null)
					{
						try 
						{
							prepStmt.close();
						} 
						catch (SQLException e2) 
						{
							// TODO: handle exception
							System.err.println("SQLException in closing Stmt:");
							e2.printStackTrace();
						}
					}
					
					if(this.conexion !=null)
					{
						cerrarConnection(this.conexion);
					}
				}
			}
			public void llenarTablaProductosMenus()throws Exception
			{
				PreparedStatement prepStmt= null;
				int cuanto=2;
				try
				{
					
					establecerConexion();
					String sql = "SELECT * FROM CLIENTE WHERE IDCLIENTE=1";
					
					prepStmt= conexion.prepareStatement(sql);
					
					
					Random r = new Random();
					
					for (int i = 0; i < cuanto; i++) {
					
						sql="INSERT INTO ProductosMenus(IDMENU,IDPRODUCTO)"+
					" VALUES("+r.nextInt(1000000)+","+r.nextInt(1000000)+")";
						
						prepStmt.execute(sql);
						if(i%1000==1000)
						{
						System.out.println(i);
						}
					}
					
					
				} 
				catch (Exception e)
				{
					// TODO: handle exception
					System.err.println("SQLException in executing:");
					e.printStackTrace();
				}
				finally
				{
					if (prepStmt!=null)
					{
						try 
						{
							prepStmt.close();
						} 
						catch (SQLException e2) 
						{
							// TODO: handle exception
							System.err.println("SQLException in closing Stmt:");
							e2.printStackTrace();
						}
					}
					
					if(this.conexion !=null)
					{
						cerrarConnection(this.conexion);
					}
				}
			}
//RFC Iteracion 4

//RFC9- CONSULTAR CONSUMO EN ROTONDANDES
			// Gerente
			public ArrayList<Usuario> consultarConsumoVersionA() throws Exception
			{
				PreparedStatement prepStmt= null;
				
				try 
				{
					establecerConexion();
					ArrayList<Usuario> usuarioConsumio= new ArrayList<>();
					String sql= "SELECT * FROM ((USUARIO INNER JOIN ORDEN ON USUARIO.IDENTIFICACION= ORDEN.IDUSUARIO)INNER JOIN RESTAURANTE ON ORDEN.IDERESTAURANTE= RESTAURANTE.IDRESTAURANTE)";
					prepStmt= conexion.prepareStatement(sql);
					long tiempoInicial = System.currentTimeMillis();
					ResultSet rs= prepStmt.executeQuery();
					long tiempoFinal= System.currentTimeMillis();
					System.out.println(tiempoFinal-tiempoInicial);
					while(rs.next())
					{
						
						Usuario usu= new Usuario(rs.getInt("IDENTIFICACION"),rs.getString("NOMBRE"), 
								rs.getString("CORREO"), rs.getString("ROL"));
						usuarioConsumio.add(usu);
					}
					return usuarioConsumio;
					
				} 
				catch (SQLException e) 
				{
					// TODO: handle exception
					System.err.println("SQLException in executing:");
					e.printStackTrace();
					throw e;
				}
				finally
				{
					if(prepStmt!=null)
					{
						try 
						{
							prepStmt.close();
							
						} 
						catch (SQLException exception) 
						{
							// TODO: handle exception
							System.err.println("SQLException in closing Stmt:");
							exception.printStackTrace();
							throw exception;
						}
					}
					if(this.conexion !=null)
					{
						cerrarConnection(this.conexion);
					}

				}
			}
			//usuario
			public ArrayList<Usuario> consultarConsumoVersionAUsuario(int idRestaurante) throws Exception
			{
				PreparedStatement prepStmt= null;
				
				try 
				{
					establecerConexion();
					ArrayList<Usuario> usuarioConsumio= new ArrayList<>();
					String sql= "SELECT * FROM ((USUARIO INNER JOIN ORDEN ON USUARIO.IDENTIFICACION= ORDEN.IDUSUARIO )INNER JOIN RESTAURANTE ON ORDEN.IDERESTAURANTE= RESTAURANTE.IDRESTAURANTE AND RESTAURANTE.IDRESTAURANTE="+idRestaurante+")";
					prepStmt= conexion.prepareStatement(sql);
					long tiempoInicial=System.currentTimeMillis();
					ResultSet rs= prepStmt.executeQuery();
					long tiempoFinal = System.currentTimeMillis();
					System.out.println(tiempoFinal-tiempoInicial);
					while(rs.next())
					{
						
						Usuario usu= new Usuario(rs.getInt("IDENTIFICACION"),rs.getString("NOMBRE"), 
								rs.getString("CORREO"), rs.getString("ROL"));
						usuarioConsumio.add(usu);
					}
					return usuarioConsumio;
					
				} 
				catch (SQLException e) 
				{
					// TODO: handle exception
					System.err.println("SQLException in executing:");
					e.printStackTrace();
					throw e;
				}
				finally
				{
					if(prepStmt!=null)
					{
						try 
						{
							prepStmt.close();
							
						} 
						catch (SQLException exception) 
						{
							// TODO: handle exception
							System.err.println("SQLException in closing Stmt:");
							exception.printStackTrace();
							throw exception;
						}
					}
					if(this.conexion !=null)
					{
						cerrarConnection(this.conexion);
					}

				}
			}
//RFC10 -CONSULTAR CONSUMO EN ROTONDANDES – RFC9-v2
			//Gerente
		public ArrayList<Usuario> consultarConsumoVersionBGerente()throws Exception
		{
			PreparedStatement prepStmt=null;
			
			try
			{
			  establecerConexion();
			  ArrayList<Usuario> usuariosNo= new ArrayList<>();
			  String sql= "SELECT * FROM USUARIO,ORDEN,RESTAURANTE WHERE NOT USUARIO.IDENTIFICACION = ORDEN.IDUSUARIO AND IDRESTAURANTE= RESTAURANTE.IDRESTAURANTE;";
			  prepStmt= conexion.prepareStatement(sql);
			  long tiempoInicial = System.currentTimeMillis();
				ResultSet rs= prepStmt.executeQuery();
				long tiempoFinal=System.currentTimeMillis();
				System.out.println(tiempoFinal-tiempoInicial);
				while(rs.next())
				{
					
					Usuario usu= new Usuario(rs.getInt("IDENTIFICACION"),rs.getString("NOMBRE"), 
							rs.getString("CORREO"), rs.getString("ROL"));
					usuariosNo.add(usu);
				}
				return usuariosNo;
			} 
			catch (SQLException e) 
			{
				// TODO: handle exception
				System.err.println("SQLException in executing:");
				e.printStackTrace();
				throw e;
			}
			finally
			{
				if(prepStmt!=null)
				{
					try 
					{
						prepStmt.close();
						
					} 
					catch (SQLException exception) 
					{
						// TODO: handle exception
						System.err.println("SQLException in closing Stmt:");
						exception.printStackTrace();
						throw exception;
					}
				}
				if(this.conexion !=null)
				{
					cerrarConnection(this.conexion);
				}

			}
		}
		
		//Usuaruio
		public ArrayList<Usuario> consultarConsumoVersionBUsuario(int idRestaurante)throws Exception
		{
			PreparedStatement prepStmt=null;
			
			try
			{
			  establecerConexion();
			  ArrayList<Usuario> usuariosNo= new ArrayList<>();
			  String sql= "SELECT * FROM USUARIO,ORDEN,RESTAURANTE WHERE NOT USUARIO.IDENTIFICACION = ORDEN.IDUSUARIO AND IDRESTAURANTE= RESTAURANTE.IDRESTAURANTE AND RESTAURANTE.IDRESTAURANTE="+idRestaurante;
			  prepStmt= conexion.prepareStatement(sql);
			  long tiempoInicial = System.currentTimeMillis();
				ResultSet rs= prepStmt.executeQuery();
				long tiempoFinal = System.currentTimeMillis();
				System.out.println(tiempoFinal-tiempoInicial);
				while(rs.next())
				{
					
					Usuario usu= new Usuario(rs.getInt("IDENTIFICACION"),rs.getString("NOMBRE"), 
							rs.getString("CORREO"), rs.getString("ROL"));
					usuariosNo.add(usu);
				}
				return usuariosNo;
			} 
			catch (SQLException e) 
			{
				// TODO: handle exception
				System.err.println("SQLException in executing:");
				e.printStackTrace();
				throw e;
			}
			finally
			{
				if(prepStmt!=null)
				{
					try 
					{
						prepStmt.close();
						
					} 
					catch (SQLException exception) 
					{
						// TODO: handle exception
						System.err.println("SQLException in closing Stmt:");
						exception.printStackTrace();
						throw exception;
					}
				}
				if(this.conexion !=null)
				{
					cerrarConnection(this.conexion);
				}

			}
		}
//RCF11- CONSULTAR FUNCIONAMIENTO 
		public ArrayList<Restaurante> consultarFuncionamiento() throws Exception
		{
			PreparedStatement prepStmt= null;
			
			try 
			{
				establecerConexion();
				ArrayList<Restaurante> maximosYMinimos= new ArrayList<>();
				String sql="SELECT IDMENU AS PRODMAS,IDRESTAURANTE AS RESTMAS, FECHA AS DIA FROM RESTAURANTE NATURAL JOIN ORDEN WHERE NUMPRODUCTOSVENDIDOS>300 AND FRECUENCIADIA>500 ORDER BY ORDEN.FECHA";
				//String sql="SELECT IDMENU,IDRESTAURANTE, FECHA FROM RESTAURANTE NATURAL JOIN ORDEN WHERE NUMPRODUCTOSVENDIDOS>300 AND FRECUENCIADIA>500 ORDER BY ORDEN.FECHA;";
				//String sql= "SELECT IDMENU AS PRODMENOS, IDRESTAURANTE AS MENOSFREC  FROM RESTAURANTE WHERE RESTAURANTE.NUMPRODUCTOSVENDIDOS<10 UNION SELECT IDMENU AS PRODMAS,IDRESTAURANTE AS MASFREC FROM RESTAURANTE WHERE RESTAURANTE.NUMPRODUCTOSVENDIDOS>100;";
				//String sql= "SELECT MAX(NUMPRODUCTOSVENDIDOS),MIN (NUMPRODUCTOSVENDIDOS), MAX(FRECUENCIADIA), MIN(FRECUENCIADIA) FROM RESTAURANTE INNER JOIN ORDEN ON RESTAURANTE.IDMENU= ORDEN.IDMENU  GROUP BY ORDEN.FECHA;";
				prepStmt= conexion.prepareStatement(sql);
				long tiempoInicial= System.currentTimeMillis();
				ResultSet rs= prepStmt.executeQuery();
				long tiempoFinal = System.currentTimeMillis();
				System.out.println(tiempoFinal-tiempoInicial);
				while (rs.next())
				{
					Restaurante restau= new Restaurante(rs.getString("NOMBRE"),rs.getInt("IDRESTAURANTE"),
							rs.getString("NOMBREREPRESENTANTE"), rs.getString("TIPOCOMIDA"));
					maximosYMinimos.add(restau);
				}
				return maximosYMinimos;
			}
			catch (SQLException e) 
			{
				// TODO: handle exception
				System.err.println("SQLException in executing:");
				e.printStackTrace();
				throw e;
			}
			finally
			{
				if(prepStmt!=null)
				{
					try 
					{
						prepStmt.close();
						
					} 
					catch (SQLException exception) 
					{
						// TODO: handle exception
						System.err.println("SQLException in closing Stmt:");
						exception.printStackTrace();
						throw exception;
					}
				}
				if(this.conexion !=null)
				{
					cerrarConnection(this.conexion);
				}
			}
			
		}
// RFC12-CONSULTAR LOS BUENOS CLIENTES
		
		
		public ArrayList<Cliente> consultarBuenosClientes()throws Exception
		{
			PreparedStatement prepStmt= null;
			try 
			{
				establecerConexion();
				ArrayList<Cliente> clientesBuenos= new ArrayList<>();
				String sql="SELECT * FROM ((CLIENTE FULL OUTER JOIN ORDEN ON CLIENTE.IDCLIENTE=ORDEN.IDCLIENTE)FULL OUTER JOIN RESTAURANTE ON RESTAURANTE.IDRESTAURANTE=ORDEN.IDERESTAURANTE)WHERE ORDEN.PRECIO > 15 AND RESTAURANTE.FRECUENCIADIA=1 ";
				prepStmt= conexion.prepareStatement(sql);
				long tiempoInicio = System.currentTimeMillis();
				ResultSet rs= prepStmt.executeQuery();
				long tiempoFinal = System.currentTimeMillis();
				System.out.println(tiempoInicio-tiempoFinal);
				while(rs.next())
				{
					Cliente bueno= new Cliente(rs.getString("NOMBRE"), rs.getInt("IDCLIENTE"), rs.getString("PREFERENCIA"));
					clientesBuenos.add(bueno);
				}
				return clientesBuenos;
			}
			catch (SQLException e) 
			{
				// TODO: handle exception
				System.err.println("SQLException in executing:");
				e.printStackTrace();
				throw e;
			}
			finally
			{
				if(prepStmt!=null)
				{
					try 
					{
						prepStmt.close();
						
					} 
					catch (SQLException exception) 
					{
						// TODO: handle exception
						System.err.println("SQLException in closing Stmt:");
						exception.printStackTrace();
						throw exception;
					}
				}
				if(this.conexion !=null)
				{
					cerrarConnection(this.conexion);
				}
			
			}
		}
}
