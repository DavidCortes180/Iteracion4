package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.Format;
import java.text.SimpleDateFormat;

import vos.Cliente;
import vos.Ingrediente;
import vos.Orden;
import vos.Producto;
import vos.Restaurante;
import vos.Usuario;
import vos.Zona;

public class ConsultaDaoTest 
{
	private Connection conexion;
	
	private String user;
	
	private String password;
	
	private String url;
	
	private String driver;
	
	Format formatoFecha= new SimpleDateFormat("yyy-mm-dd");
	
	private void establecerConexion()throws SQLException
	{
		System.out.println("Connecting to: " + "jdbc:oracle:thin:@fn3.oracle.virtual.uniandes.edu.co:1521:prod" + " With user: " + "ISIS2304B141720");
		conexion= DriverManager.getConnection("jdbc:oracle:thin:@fn3.oracle.virtual.uniandes.edu.co:1521:prod", "ISIS2304B141720", "VKoxXPEznW");	
	}
	
	public void cerrarConexion(Connection pConnection) throws SQLException
	{
		try {
			pConnection.close();
			pConnection=null;
		} 
		catch (SQLException exception) 
		{
			// TODO: handle exception
			System.err.println("SQLException in closing Connection:");
			exception.printStackTrace();
			throw exception;
		}
	}
	
	//REQUERIMIENTOS
	
	//RF1
	public final void testRegistrarUsuario() throws Exception
	{
		PreparedStatement prepStmt= null;
		try {
			establecerConexion();
			String sql= "INSERT INTO USUARIO(IDEUSUARIO, NOMBRE, CORREO, ROL)"
					+"VALUES (100,'Camila','Torres','c.torres@uniandes.edu.co',190263894,'OPERARIO')";
			System.out.println(sql);
			prepStmt= conexion.prepareStatement(sql);
			prepStmt.execute();

		} 
		catch (Exception e) 
		{
			// TODO: handle exception
			System.err.println("SQLException in executing:");
			e.printStackTrace();
			assert true;
		}
		finally 
		{
			if(prepStmt!=null)
			{
				try 
				{
					prepStmt.close();
				} 
				catch (SQLException exception)
				{
					// TODO: handle exception
					System.err.println("SQLException in closing Stmt:");
					exception.printStackTrace();
					assert(true);
				}
			}
			if (this.conexion!=null) 
			{
				cerrarConexion(this.conexion);
			}
		}
	}
	
	//RF2
	public void testregistrarCliente(Usuario user) throws Exception
	{
		if(user.getRol()==Usuario.ADMINISTRADOR)
		{
		PreparedStatement prepStmt = null;
		try
		{
			establecerConexion();
			String sql = "INSERT INTO CLIENTE(IDCLIENTE, NOMBRE)"+
					"VALUES(23, 'daniel')";
			System.out.println(sql);
			prepStmt= conexion.prepareStatement(sql);
			prepStmt.execute();
		} 
		catch (Exception e)
		{
			// TODO: handle exception
			System.err.println("SQLException in executing:");
			e.printStackTrace();
			assert true;
		}
		finally
		{
			if (prepStmt!=null)
			{
				try 
				{
					prepStmt.close();
				} 
				catch (SQLException e2) 
				{
					// TODO: handle exception
					System.err.println("SQLException in closing Stmt:");
					e2.printStackTrace();
					assert true;
				}
			}
			
			if(this.conexion !=null)
			{
				cerrarConexion(this.conexion);
			}
			
		}
		}
		else
		{
			System.err.println("El usuario no tiene los privilegios necesarios");
		}
	}
	
	//RF3 
	public void registrarRestaurante( Usuario pUser)throws Exception
	{
		if(pUser.getRol()==Usuario.ADMINISTRADOR)
		{
			PreparedStatement prepStmt= null;

			try 
			{
				establecerConexion();
				String sql= "INSERT INTO RESTAURANTE(IDRESTAURANTE,NOMBRE,NOMBREREPRESENTANTE,TIPOCOMIDA,ZONA)"
						+ "VALUES(101,'donaarepa','juan', 'fritas', '5')";

				System.out.println(sql);
				prepStmt=conexion.prepareStatement(sql);
				prepStmt.execute();
			} 
			catch (Exception e) 
			{
				// TODO: handle exception
				System.err.println("SQLException in executing:");
				e.printStackTrace();
				assert true;
			}
			finally
			{
				if(prepStmt !=null)
				{
					try {
						prepStmt.close();
					} catch (SQLException e2) 
					{
						// TODO: handle exception
						System.err.println("SQLException in closing Stmt:");
						e2.printStackTrace();
						assert true;
					}

				}
				if(this.conexion !=null)
				{
					cerrarConexion(this.conexion);
				}
			}

		}
	}
	// RF4 Registrar Producto
			public void registrarProducto(Producto producto,Usuario user) throws Exception
			{
				if(user.getRol()==Usuario.RESTAURANTE)
				{
					PreparedStatement prepStmt = null;
					int personalisadoTraduccion;
					if(producto.isEstaPersonalizado()==true)
					{
						personalisadoTraduccion = 1;
					}
					else
					{
						personalisadoTraduccion = 0;
					}
					try 
					{
						
						System.out.println(producto);
						establecerConexion();
						String sql = "INSERT INTO PRODUCTO(IDPRODUCTO,PRECIO,ESTAPERSONALIZADO)"
								+"VALUES(101, 11, 0)";
						System.out.println(sql);
						prepStmt= conexion.prepareStatement(sql);
						prepStmt.execute();
					} 
					catch (Exception e) 
					{
						// TODO: handle exception
						System.err.println("SQLException in executing:");
						e.printStackTrace();
						assert true;
					}
					finally
					{
						if(prepStmt !=null)
						{
							try {
								prepStmt.close();
								
							}
							catch (SQLException e2) 
							{
								// TODO: handle exception
								System.err.println("SQLException in closing Stmt:");
								e2.printStackTrace();
								assert true;
							}
						}
						if(this.conexion!=null)
						{
							cerrarConexion(this.conexion);
						}
					}
				}
				else
				{
					System.err.println("El usuario no tiene los privilegios necesarios");
				}
			}
		// RF5 Registrar ingrediente
		
			public void registrarIngrediente(Usuario pUser)throws Exception
			{
			  if(pUser.getRol()==Usuario.ADMINISTRADOR)
				{
					PreparedStatement prepStmt = null;

					try 
					{
						establecerConexion();
						String sql = "INSERT INTO INGREDIENTE(IDINGREDIENTE,NOMBRE,DESCRIPCION,TRADUCCION)"
								+"VALUES(101, 'huevo','huevogallina', 'egg')";
						System.out.println(sql);
						prepStmt= conexion.prepareStatement(sql);
						prepStmt.execute();
					} 
					catch (Exception e) 
					{
						// TODO: handle exception
						System.err.println("SQLException in executing:");
						e.printStackTrace();
						assert true;
					}
					finally
					{
						if(prepStmt !=null)
						{
							try {
								prepStmt.close();

							}
							catch (SQLException e2) 
							{
								// TODO: handle exception
								System.err.println("SQLException in closing Stmt:");
								e2.printStackTrace();
								assert true;
							}
						}
						if(this.conexion!=null)
						{
							cerrarConexion(this.conexion);
						}
					}
				}
			}
		//RF6 Registrar Menu
			public void registrarMenu(vos.Menu menu, Usuario user)throws Exception
			{
				if(user.getRol()==Usuario.RESTAURANTE)
				{
					PreparedStatement prepStmt = null;
					int personalisadoTraduccion;
					if(menu.isEstaPersonalisado()==true)
					{
						personalisadoTraduccion = 1;
					}
					else
					{
						personalisadoTraduccion = 0;
					}
					try 
					{
						
						System.out.println(menu);
						establecerConexion();
						
						String sql = "INSERT INTO MENU(IDMENU,NOMBRE,PRECIO,ESTAPERSONALISADO,IDRESTAURENTE)"
								+"VALUES(101,'infantil', 13, 0, 101)";
						System.out.println(sql);
						prepStmt= conexion.prepareStatement(sql);
						prepStmt.execute();
					} 
					catch (Exception e) 
					{
						// TODO: handle exception
						System.err.println("SQLException in executing:");
						e.printStackTrace();
						assert true;
					}
					finally
					{
						if(prepStmt !=null)
						{
							try {
								prepStmt.close();
								
							}
							catch (SQLException e2) 
							{
								// TODO: handle exception
								System.err.println("SQLException in closing Stmt:");
								e2.printStackTrace();
								assert true;
							}
						}
						if(this.conexion!=null)
						{
							cerrarConexion(this.conexion);
						}
					}
				}
				else
				{
					System.err.println("El usuario no tiene los privilegios necesarios");
				}
			}
		//RF7 Registrar zona
		
		public void registrarZona()throws Exception
		{
			PreparedStatement prepStmt= null;
			
			try 
			{
				establecerConexion();
				String sql = "INSERT INTO ZONA(NUMEROZONA,CAPACIDAD,ABIERTO,APTO,DESCRIPCION)"
						+"VALUES(5,100,1,1,'aireacondicionado')";
				System.out.println(sql);
				prepStmt=conexion.prepareStatement(sql);
				prepStmt.execute();
			} 
			catch (Exception e) 
			{
				// TODO: handle exception
				System.err.println("SQLException in executing:");
				e.printStackTrace();
				assert true;
			}
			finally {
				if(prepStmt !=null)
				{
					try {
						prepStmt.close();
						
					}
					catch (SQLException e2) 
					{
						// TODO: handle exception
						System.err.println("SQLException in closing Stmt:");
						e2.printStackTrace();
						assert true;
					}
				}
				if(this.conexion!=null)
				{
					cerrarConexion(this.conexion);
				}
			}
		}
		
		//RF8 Registrar Preferencia Del Cliente
		public void registrarPreferencia()throws Exception
		{
			PreparedStatement prepStmt= null;
			
			try 
			{
				
				establecerConexion();
				String sql = "UPDATE CLIENTE SET PREFERENCIA=ENTRADA WHERE IDCLIENTE = 6";
						
				System.out.println(sql);
				prepStmt=conexion.prepareStatement(sql);
				prepStmt.execute();
			} 
			catch (Exception e) 
			{
				// TODO: handle exception
				System.err.println("SQLException in executing:");
				e.printStackTrace();
				assert true;
			}
			finally {
				if(prepStmt !=null)
				{
					try {
						prepStmt.close();
						
					}
					catch (SQLException e2) 
					{
						// TODO: handle exception
						System.err.println("SQLException in closing Stmt:");
						e2.printStackTrace();
					}
				}
				if(this.conexion!=null)
				{
					cerrarConexion(this.conexion);
				}
			}
		}
	// R9 REGISTRAR PEDIDO DE UN PRODUCTO
		
		public void registrarPedidoDeUnProducto()throws Exception
		{
			PreparedStatement prepStmt=null;
			
			try 
			{
				establecerConexion();
				String sql= "INSERT INTO ORDEN(IDORDEN,PRECIOTOTAL,IDMESA,IDUSUARIO,"
						+ "NOMBRECLIENTE,FECHA,HORA)VALUES(101,13,101,101, 'erika', "
						+ "TO DATE ('2015-02-04 12:00:00')";
				System.out.println(sql);
				prepStmt=conexion.prepareStatement(sql);
				prepStmt.execute();
			} 
			catch (Exception e)
			{
				// TODO: handle exception
				System.err.println("SQLException in executing:");
				e.printStackTrace();
				assert true;
			}
			finally
			{
				if(prepStmt !=null)
				{
					try {
						prepStmt.close();
						
					}
					catch (SQLException e2) 
					{
						// TODO: handle exception
						System.err.println("SQLException in closing Stmt:");
						e2.printStackTrace();
						assert true;
					}
				}
				if(this.conexion!=null)
				{
					cerrarConexion(this.conexion);
				}
			}
		}
		//R10 RESGISTRAR EL SERVICIO DE UN PRODUCTO
		
			public void registrarServicioDeUnProducto()throws Exception
			{
				PreparedStatement prepStmt=null;
				try
				{
					establecerConexion();
					String sql="SELECT DISPONIBLE FROM PRODUCTOS WHERE IDPRODUCTO= 9";
					prepStmt= conexion.prepareStatement(sql);
					ResultSet rs= prepStmt.executeQuery();
					int disponibleActual = rs.getInt(1);
					sql = "UPDATE PRODUCTOS SET DISPONIBLE="+(disponibleActual-1)+"WHERE IDPRODUCTO= 9";
					prepStmt.close();
					prepStmt=conexion.prepareStatement(sql);
					prepStmt.execute();
				}
				catch(Exception e)
				{
					System.err.println("SQLException in executing:");
					e.printStackTrace();
					assert true;
				}
				finally
				{
					if(prepStmt !=null)
					{
						try {
							prepStmt.close();
							
						}
						catch (SQLException e2) 
						{
							// TODO: handle exception
							System.err.println("SQLException in closing Stmt:");
							e2.printStackTrace();
							assert true;
						}
					}
					if(this.conexion!=null)
					{
						cerrarConexion(this.conexion);
					}
				}
			}
			//iteracion 3
			//UPDATE
			//DELETE
			//INSERT
			//SELECT
}
